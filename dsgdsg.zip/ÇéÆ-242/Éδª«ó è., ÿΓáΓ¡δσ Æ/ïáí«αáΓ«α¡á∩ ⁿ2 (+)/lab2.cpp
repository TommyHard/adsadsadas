﻿#include <stdlib.h>
#include <locale.h>
#include <stdio.h>
#include <iostream>

#define ArrayLength(Input) sizeof(Input) / sizeof(*Input)
#define FilePath "lab2_Cars.txt"

/*
> 10. Регистрационный номер автомобиля, марка, пробег.
• Заполнение таблицы с клавиатуры
• Просмотр таблицы
• Загрузка и сохранение таблицы в текстовом файле
• Редактирование записи
• Удаление записи
• Сортировка таблицы в порядке возрастания заданного поля
• Поиск в таблице элемента с заданным значением поля или с наиболее близким к нему по значению
• Вычисление с проверкой и использованием всех записей по заданному условию и формуле (например, общая сумма на всех счетах)
*/

struct Car
{
	char Model[15] {};
	char RegistrationNumber[6];
	int Miliage;
};

struct Table
{
	int TotalNumberOfEntries = 0;
	struct Car Cars[50];
};

#pragma region Utilities
void ClearConsole()
{
	system("cls");
}
#pragma endregion

#pragma region Functions

void ShowMenu()
{
	char Functions[][50] =
	{
		"просмотреть текущие данные",
		"поставить на учёт новый автомобиль",
		"загрузить информацию из файла",
		"сохранить информацию в файл",
		"отсортировать данные",
		"отфильтровать данные",
		"изменить данные",
		"удалить данные",
		"получить общую сумму пробега по всем автомобилям"
	};
	//
	for (int i = 0; i < ArrayLength(Functions); i++)
	{
		printf("  >> %d, чтобы %s\n", i + 1, Functions[i]);
	}
	//
	printf(" > ");
}

void ShowInformation(struct Table* CurrentTable)
{
	int TotalEntries = CurrentTable->TotalNumberOfEntries;
	//
	if (TotalEntries != 0)
	{
		printf("  \033[36m---------------------------------------------------------------------------------------\033[0m\n");
		//
		for (int i = 0; i < TotalEntries; i++)
		{
			printf("\033[36m  %02d. Регистрационный номер: %s \t\tПробег: %d \t\tМодель: %s\033[0m\n", 
				i + 1, 
				CurrentTable->Cars[i].RegistrationNumber,
				CurrentTable->Cars[i].Miliage,
				CurrentTable->Cars[i].Model);
		}
		//
		printf("  \033[36m---------------------------------------------------------------------------------------\033[0m\n");
	}
	else
	{
		printf(">>\033[31m Нет данных для просмотра \033[0m\n");
	}
}

void ShowSearchInformation(struct Table* CurrentTable, int ID)
{
	printf("\033[36m  %02d. Регистрационный номер: %s \t\tПробег: %d \t\tМодель: %s\033[0m\n",
		ID + 1,
		CurrentTable->Cars[ID].RegistrationNumber,
		CurrentTable->Cars[ID].Miliage,
		CurrentTable->Cars[ID].Model);
}

void CarInformation(struct Table* CurrentTable, int ArrayCell)
{
	printf(">> Введите марку машины: \n > ");
	scanf("%s", &(CurrentTable->Cars[ArrayCell].Model));
	//
	printf(">> Введите регистрационный номер в формате X000XX: \n > ");
	scanf("%s", &(CurrentTable->Cars[ArrayCell].RegistrationNumber));
	//
	printf(">> Введите пробег: \n > ");
	scanf("%d", &(CurrentTable->Cars[ArrayCell].Miliage));
}

void SaveToFile(struct Table* CurrentTable, FILE* LocalFile)
{
	int TotalEntries = CurrentTable->TotalNumberOfEntries;
	//
	if (TotalEntries != 0)
	{
		LocalFile = fopen(FilePath, "w");
		//
		for (int i = 0; i < TotalEntries; i++)
		{
			fprintf(LocalFile, "%s %s %d\n",
				CurrentTable->Cars[i].Model,
				CurrentTable->Cars[i].RegistrationNumber,
				CurrentTable->Cars[i].Miliage);
		}
		//
		fclose(LocalFile);
		//
		ClearConsole();
		printf(">>\033[32m Данные сохранены в файл \033[0m\n");
	}
	else
	{
		printf(">>\033[31m Нет данных для сохранения \033[0m\n");
	}
}

void LoadFromFile(struct Table* CurrentTable, FILE* LocalFile)
{
	int TotalEntries = CurrentTable->TotalNumberOfEntries;
	//
	if ((LocalFile = fopen(FilePath, "r")) != NULL)
	{
		for(int i = TotalEntries; !feof(LocalFile); i++)
		{
			fscanf(LocalFile, "%s %s %d\n",
				&CurrentTable->Cars[i].Model,
				&CurrentTable->Cars[i].RegistrationNumber,
				&CurrentTable->Cars[i].Miliage);;
			//
			CurrentTable->TotalNumberOfEntries++;
		}
		//
		fclose(LocalFile);
		//
		ClearConsole();
		printf(">>\033[32m Из файла было загружено записей: %d \033[0m\n", CurrentTable->TotalNumberOfEntries - TotalEntries);
	}
	else
	{
		printf(">>\033[31m Нет данных для чтения \033[0m\n");
	}
}

void AddNewCar(struct Table* CurrentTable)
{
	int CarID = CurrentTable->TotalNumberOfEntries;
	//
	CarInformation(CurrentTable, CarID);
	//
	ClearConsole();
	printf(">>\033[32m Машина добавлена \033[0m\n");
	//
	CurrentTable->TotalNumberOfEntries++;
}

void RemoveCar(struct Table* CurrentTable)
{
	int TotalEntries = CurrentTable->TotalNumberOfEntries;
	//
	if (TotalEntries != 0)
	{
		ShowInformation(CurrentTable);
		//
		printf(">> Укажите номер строки, которую хотите удалить\n > ");
		//
		int CarID;
		scanf("%d", &CarID);
		CarID -= 1;
		//
		for (int i = CarID; i < CurrentTable->TotalNumberOfEntries; i++)
		{
			CurrentTable->Cars[i] = CurrentTable->Cars[i + 1];
		}
		//
		CurrentTable->TotalNumberOfEntries--;
		//
		ClearConsole();
		printf(">>\033[32m Информация удалена \033[0m\n");
	}
	else
	{
		printf(">>\033[31m Нет данных для удаления \033[0m\n");
	}
}

void EditCar(struct Table* CurrentTable)
{
	int TotalEntries = CurrentTable->TotalNumberOfEntries;
	//
	if (TotalEntries != 0)
	{
		ShowInformation(CurrentTable);
		//
		printf(">> Укажите номер строки, которую хотите изменить\n > ");
		//
		int CarID;
		scanf("%d", &CarID);
		CarID -= 1;
		//
		CarInformation(CurrentTable, CarID);
		//
		ClearConsole();
		printf(">>\033[32m Информация изменена \033[0m\n");
	}
	else
	{
		printf(">>\033[31m Нет данных для редактирования \033[0m\n");
	}
}

void TotalCarsMileage(struct Table* CurrentTable)
{
	int TotalEntries = CurrentTable->TotalNumberOfEntries;
	//
	if (TotalEntries > 1)
	{
		int TotalMileage = 0;
		//
		for (int i = 0; i < TotalEntries; i++)
		{
			TotalMileage += CurrentTable->Cars[i].Miliage;
		}
		//
		printf(">>\033[32m На %d автомобилей(ля), суммарный пробег равен: %d км  \033[0m\n", TotalEntries, TotalMileage);
	}
	else
	{
		printf(">>\033[31m Недостаточно данных для отчёта \033[0m\n");
	}
}

void TableSort(struct Table* CurrentTable)
{
	int TotalEntries = CurrentTable->TotalNumberOfEntries;
	//
	if (TotalEntries > 1)
	{
		ShowInformation(CurrentTable);
		//
		printf(">> Список доступных сортировк. Для вызова нажмите соответствующую кнопку\n");
		//
		char AvailableSorts[][30] =
		{
			"регистрационному номеру",
			"пробегу",
			"моделям"
		};
		//
		for (int i = 0; i < ArrayLength(AvailableSorts); i++)
		{
			printf("  >> %d, чтобы отсортировать по %s\n", i + 1, AvailableSorts[i]);
		}
		//
		printf(" > ");
		//
		int CurrentSort;
		int Sorted = 1;
		scanf("%d", &CurrentSort);
		//
		switch (CurrentSort)
		{
			case 1: // По номеру
				for (int i = 0; i < (CurrentTable->TotalNumberOfEntries) - 1; i++)
				{
					for (int j = i + 1; j < CurrentTable->TotalNumberOfEntries; j++)
					{
						if (strcmp(CurrentTable->Cars[j].RegistrationNumber, CurrentTable->Cars[i].RegistrationNumber) < 0)
						{
							struct Car _Cars = CurrentTable->Cars[i];
							//
							CurrentTable->Cars[i] = CurrentTable->Cars[j];
							CurrentTable->Cars[j] = _Cars;
						}
					}
				}
				break;
			case 2: // По пробегу
				for (int i = 0; i < (CurrentTable->TotalNumberOfEntries) - 1; i++)
				{
					for (int j = i + 1; j < CurrentTable->TotalNumberOfEntries; j++)
					{
						if (CurrentTable->Cars[j].Miliage - CurrentTable->Cars[i].Miliage < 0)
						{
							struct Car _Cars = CurrentTable->Cars[i];
							CurrentTable->Cars[i] = CurrentTable->Cars[j];
							CurrentTable->Cars[j] = _Cars;
						}
					}
				}
				break;
			case 3: // По моделям
				for (int i = 0; i < (CurrentTable->TotalNumberOfEntries) - 1; i++)
				{
					for (int j = i + 1; j < CurrentTable->TotalNumberOfEntries; j++)
					{
						if (strcmp(CurrentTable->Cars[j].Model, CurrentTable->Cars[i].Model) < 0)
						{
							struct Car _Cars = CurrentTable->Cars[i];
							CurrentTable->Cars[i] = CurrentTable->Cars[j];
							CurrentTable->Cars[j] = _Cars;
						}
					}
				}
				break;
			default:
				Sorted = 0;
				//
				ClearConsole();
				printf(">>\033[31m Запрашиваемая команда сортировки не найдена \033[0m\n");
				break;
		}
		//
		if (Sorted == 1)
		{
			ClearConsole();
			printf(">>\033[32m Данные отсортированы \033[0m\n");
		}
	}
	else
	{
		printf(">>\033[31m Недостаточно данных для сортировки \033[0m\n");
	}
}

#pragma region Search

char* SearchInString(char* Input, char* Request)
{
	int i;
	for (; *Input != '\0'; Input++)
	{
		for (i = 0; Request[i] != '\0' && Request[i] == Input[i]; i++);
		//
		if (Request[i] == '\0')
		{
			return Input;
		}
	}
	//
	return NULL;
}

void RegistrationNumberSearch(struct Table* CurrentTable, char* Request)
{
	int InformationFound = 0;
	//
	ClearConsole();
	printf("\033[36m>> Результаты поиска\033[0m\n");
	printf("  \033[36m---------------------------------------------------------------------------------------\033[0m\n");
	//
	for (int i = 0; i < CurrentTable->TotalNumberOfEntries; i++)
	{
		if (SearchInString(CurrentTable->Cars[i].RegistrationNumber, Request))
		{
			InformationFound = 1;
			//
			ShowSearchInformation(CurrentTable, i);
		}
	}
	//
	printf("  \033[36m---------------------------------------------------------------------------------------\033[0m\n");
	//
	if (InformationFound == 0)
	{
		ClearConsole();
		printf(">>\033[31m По указанным данным информация отсутствует \033[0m\n");
	}
}

void CarMiliageSearch(struct Table* CurrentTable, int Request)
{
	int InformationFound = 0;
	//
	ClearConsole();
	printf("\033[36m>> Результаты поиска\033[0m\n");
	printf("  \033[36m---------------------------------------------------------------------------------------\033[0m\n");
	//
	for (int i = 0; i < CurrentTable->TotalNumberOfEntries; i++)
	{
		if (Request == CurrentTable->Cars[i].Miliage)
		{
			InformationFound = 1;
			//
			ShowSearchInformation(CurrentTable, i);
		}
		else if (Request > CurrentTable->Cars[i].Miliage - 150 && Request < CurrentTable->Cars[i].Miliage + 150)
		{
			InformationFound = 1;
			//
			ShowSearchInformation(CurrentTable, i);
		}
	}
	//
	printf("  \033[36m---------------------------------------------------------------------------------------\033[0m\n");
	//
	if (InformationFound == 0)
	{
		ClearConsole();
		printf(">>\033[31m По указанным данным информация отсутствует \033[0m\n");
	}
}

void ModelSearch(struct Table* CurrentTable, char* Request)
{
	int InformationFound = 0;
	//
	ClearConsole();
	printf("\033[36m>> Результаты поиска\033[0m\n");
	printf("  \033[36m---------------------------------------------------------------------------------------\033[0m\n");
	//
	for (int i = 0; i < CurrentTable->TotalNumberOfEntries; i++)
	{
		if (SearchInString(CurrentTable->Cars[i].Model, Request))
		{
			InformationFound = 1;
			//
			ShowSearchInformation(CurrentTable, i);
		}
	}
	//
	printf("  \033[36m---------------------------------------------------------------------------------------\033[0m\n");
	//
	if (InformationFound == 0)
	{
		ClearConsole();
		printf(">>\033[31m По указанным данным информация отсутствует \033[0m\n");
	}
}

void Search(struct Table* CurrentTable)
{
	int TotalEntries = CurrentTable->TotalNumberOfEntries;
	//
	if (TotalEntries != 0)
	{
		printf(">> Список доступных команд для поиска. Для вызова нажмите соответствующую кнопку\n");
		//
		char AvailableSearch[][30] =
		{
			"регистрационному номеру",
			"пробегу",
			"модели"
		};
		//
		for (int i = 0; i < ArrayLength(AvailableSearch); i++)
		{
			printf("  >> %d, чтобы искать по %s\n", i + 1, AvailableSearch[i]);
		}
		//
		printf(" > ");
		//
		int CurrentSearch;
		int InformationFound = 0;
		char Request[15];
		//
		scanf("%d", &CurrentSearch);
		//
		switch (CurrentSearch)
		{
			case 1: // Поиск по номеру
				printf(">> Введите номер для поиска в формате X000XX\n > ");
				scanf("%s", Request);
				//
				RegistrationNumberSearch(CurrentTable, Request);
				break;
			case 2: // Поиск по пробегу
				printf(">> Введите пробег автомобиля для поиска\n > ");
				scanf("%s", Request);
				//
				CarMiliageSearch(CurrentTable, atoi(Request));
				break;
			case 3: // Поиск по модели
				printf(">> Введите название модели для поиска\n > ");
				scanf("%s", Request);
				//
				ModelSearch(CurrentTable, Request);
				break;
			default:
				ClearConsole();
				printf(">>\033[31m Запрашиваемая команда поиска не найдена \033[0m\n");
				break;
		}
	}
	else
	{
		printf(">>\033[31m Недостаточно данных для поиска \033[0m\n");
	}
}
#pragma endregion

#pragma endregion


void FunctionSelection(struct Table* CurrentTable, FILE* LocalFile)
{
	int CurrentAction;
	scanf("%d", &CurrentAction);
	//
	ClearConsole();
	//
	switch (CurrentAction)
	{
		case 1:
			ShowInformation(CurrentTable);
			break;
		case 2:
			AddNewCar(CurrentTable);
			break;
		case 3:
			LoadFromFile(CurrentTable, LocalFile);
			break;
		case 4:
			SaveToFile(CurrentTable, LocalFile);
			break;
		case 5:
			TableSort(CurrentTable);
			break;
		case 6:
			Search(CurrentTable);
			break;
		case 7:
			EditCar(CurrentTable);
			break;
		case 8:
			RemoveCar(CurrentTable);
			break;
		case 9:
			TotalCarsMileage(CurrentTable);
			break;
		default:
			printf(">>\033[31m Выбранная функция не найдена, попробуйте другую \033[0m\n");
			break;
	}
}

void main()
{
	setlocale(LC_ALL, "Russian");
	ClearConsole();
	//
	struct Table Table;
	FILE LocalFile{};
	//
	printf(">> Список доступных функций. Для вызова нажмите соответствующую кнопку\n");
	//
	while (1)
	{
		ShowMenu();
		//
		FunctionSelection(&Table, &LocalFile);
	}
}