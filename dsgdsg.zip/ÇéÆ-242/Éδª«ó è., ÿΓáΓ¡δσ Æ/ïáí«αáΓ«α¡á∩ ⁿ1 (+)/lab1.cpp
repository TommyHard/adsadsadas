﻿#include <stdio.h>
#include <stdlib.h>
#include <iostream>

// 8. Функция находит в строке самое длинное слово и возвращает указатель на него. 
// С ее помощью реализовать размещение слов в выходной строке в порядке убывания их длины.

char* ReadingTheInput(int* Length)
{
	*Length = 0;
	int Capacity = 1;
	char* TempString = (char*)malloc(sizeof(char)); // Динамическая пустая строка
	char Input = getchar(); // Читаем входные данные
	//
	while (Input != '\n')
	{
		*(TempString + (*Length)++) = Input; // Новый символ в строку
		//
		if (*Length >= Capacity)
		{
			Capacity *= 2; // Увеличиваем емкость строки в 2 раза
			TempString = (char*)realloc(TempString, Capacity * sizeof(char)); // Создаем новую строку с увеличенной емкостью  
		}
		//
		Input = getchar(); // Читаем последующие символы        
	}
	//
	*(TempString + *Length) = '\0'; // Ставим нуль-терминатор в качестве завершения строки
	//
	return TempString;
}

void SortArray(char* Input, int ArraySize, char* OutputArray, int WordPosition, int WordLength, int* EndPosition)
{
	int i = *EndPosition; // Позиция следующего слова в новом массиве 
	//
	for (int j = WordPosition; i < WordLength + *EndPosition; i++, j++) // Переносим длинное слово в новый массив
	{
		*(OutputArray + i) = *(Input + j);
		*(Input + j) = ' '; // Убираем слово из исходного массива
	}
	//
	if (i + 1 < ArraySize) // Пробел между словами
	{
		*(OutputArray + i) = ' ';
	}
	//
	*EndPosition = i + 1; // Сохраняем позицию для следующего слова
}

// Функция поиска самых длинных слов
int FindLongestWord(char* Input, int ArraySize, char* OutputArray, int* EndPosition)
{
	int LongestWordPosition = 0; // Позиция начала самого длинного слова
	int LongestWordLength = 0; // Максимальная длина слова
	int CurrentLength = 0; // Подсчет текущей длины
	//
	for (int i = 0; i <= ArraySize; i++) // Перебор всех символов массива
	{
		if (ArraySize != i && *(Input + i) != ' ') // Разделение слов от пробелов
		{
			CurrentLength++; // Если слово - считаем его длину
		}
		else
		{
			if (CurrentLength > LongestWordLength)
			{
				LongestWordLength = CurrentLength;
				LongestWordPosition = i - CurrentLength; // Определеяем позицию длинного слова
			}
			//
			CurrentLength = 0;
		}
	}
	//
	SortArray(Input, ArraySize, OutputArray, LongestWordPosition, LongestWordLength, EndPosition); // Нашли максимальное слово, записываем его в новый массив
	//
	return LongestWordPosition; // Возвращаем указатель на длинное слово
}

int FindWord(char* Input)
{
	int ArraySize = strlen(Input);
	//
	for (int i = 0; i < ArraySize; i++)
	{
		if (*(Input + i) != ' ')
		{
			return 1; // Слово найдено
		}
	}
	//
	return 0; // Слово не найдено
}

void ArrayPrint(char *Input, int ArraySize)
{
	for (int i = 0; i < ArraySize; i++)
	{
		printf("%c", *(Input + i));
	}
}

void main()
{
	setlocale(LC_ALL, "Rus");
	//
	int Length = 0;
	char* Victim = ReadingTheInput(&Length);
	//
	system("cls"); // Чистим консоль (для эстетики)
	//
	printf("Вы ввели: ");
	ArrayPrint(Victim, Length);
	//
	char* SortedArray = new char[Length]; // Отсортированный массив
	//
	int EndPosition = 0;
	//
	while (FindWord(Victim))
	{
		FindLongestWord(Victim, Length, SortedArray, &EndPosition); // Вывод указателя на самые длинные слова
	}
	//
	printf("\n");
	printf("Отсортированный массив: ");
	ArrayPrint(SortedArray, Length);
	printf("\n");
}