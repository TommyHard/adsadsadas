﻿#include <iostream>
#include <clocale>

using namespace std;

/*
* #7
* Очередь моделируется при помощи динамического массива указателей на линейные массивы размерности N целых.
Указатели на первый и последний  элементы очереди – два индекса – в массиве указателей и линейном массиве.
В операции добавления при переполнении текущего линейного массива в массив указателей добавляется новый,
в операции извлечения – при переходе к следующему линейному массиву текущий утилизируется
(указатели в массиве указателей смещаются к началу).
*/

class Queue
{
private:
    static const int N = 3;
    int** queueArray;
    int headIndex;
    int tailIndex;
    int headArrayIndex;
    int tailArrayIndex;

public:
    Queue()
    {
        queueArray = new int* [N];
        //
        for (int i = 0; i < N; i++)
        {
            queueArray[i] = new int[N];
        }
        //
        headIndex = tailIndex = -1;
        headArrayIndex = tailArrayIndex = 0;
    }

    ~Queue()
    {
        for (int i = 0; i < N; i++)
        {
            delete[] queueArray[i];
        }
        //
        delete[] queueArray;
    }

    bool isFull() const
    {
        if (tailIndex == N * (tailArrayIndex + 1) - 1)
        {
            return true;
        }
        //
        return false;
    }

    bool isEmpty() const
    {
        if (headIndex == -1)
        {
            return true;
        }
        //
        return false;
    }

    void enqueue(int value)
    {
        if (isFull())
        {
            tailArrayIndex++;
            queueArray[tailArrayIndex] = new int[N];
            tailIndex = tailArrayIndex * N;
        }
        else if (isEmpty())
        {
            headIndex = tailIndex = 0;
        }
        else if (tailIndex == N * tailArrayIndex + N - 1)
        {
            tailArrayIndex++;
            tailIndex = tailArrayIndex * N;
        }
        else
        {
            tailIndex++;
        }
        //
        queueArray[tailArrayIndex][tailIndex % N] = value;
    }

    int dequeue()
    {
        int value = queueArray[headArrayIndex][headIndex % N];
        //
        if (headIndex == tailIndex)
        {
            headIndex = tailIndex = -1;
            headArrayIndex = tailArrayIndex = 0;
        }
        else if (headIndex == N * headArrayIndex + N - 1)
        {
            headArrayIndex++;
            headIndex = headArrayIndex * N;
        }
        else
        {
            headIndex++;
        }
        //
        return value;
    }

    void printQueue() const
    {
        for (int i = headArrayIndex; i <= tailArrayIndex; i++)
        {
            int start = i == headArrayIndex ? headIndex % N : 0;
            int end = i == tailArrayIndex ? tailIndex % N : N - 1;
            //
            for (int j = start; j <= end; j++)
            {
                cout << queueArray[i][j] << ' ';
            }
            //
            cout << '\n';
        }
    }
};

void main()
{
    setlocale(LC_ALL, "Russian");
    //
    Queue queue;
    int choice = 0;
    //
    while (true)
    {
        cout << "Выберите действие:\n";
        cout << "1. Добавить элемент в очередь\n";
        cout << "2. Убрать элемент из очереди\n";
        cout << "3. Показать очередь\n";
        //
        cin >> choice;
        //
        switch (choice)
        {
        case 1:
            int value;
            //
            cout << "Введите значение: ";
            cin >> value;
            //
            queue.enqueue(value);
            break;
        case 2:
            if (queue.isEmpty())
            {
                cout << "Очередь пуста\n";
            }
            else
            {
                int value = queue.dequeue();
                //
                cout << "Удалённый элемент: " << value << '\n';
            }
            break;
        case 3:
            if (queue.isEmpty())
            {
                cout << "Очередь пуста\n";
            }
            else
            {
                cout << "Очередь:\n";
                //
                queue.printQueue();
            }
            break;
        default:
            cout << "Неправильный выбор\n";
            break;
        }
    }
}