#include <stdio.h>
#include <malloc.h>

struct tree {
    int val[2];
    struct tree *left, *center, *right;
};

struct tree* LeafTree(int v) { // function to create a new leaf of the tree

    struct tree *tmp = (struct tree*)malloc(sizeof(struct tree));
    tmp->left = tmp->right = tmp->center = NULL;
    tmp->val[0] = v; tmp->val[1] = 0;
    return tmp;
}

struct tree* Insert(struct tree **pp, int v) { // function of inserting an element into a tree while maintaining the tree order

    if ((*pp) == NULL) { // creating a new leaf of the tree
        (*pp) = LeafTree(v);
        return(*pp);
    }

    if ((v == (*pp)->val[0]) || (v == (*pp)->val[1])) return (*pp);
    if ((v > (*pp)->val[0]) && ((*pp)->val[0]) && ((*pp)->val[1] == 0)) {
        (*pp)->val[1] = v; return (*pp); // the second number is added to the leaf of the tree
    }
    /* recursive search for the insertion point of an element */
    if ((*pp)->val[0] > v)
        (*pp)->left = Insert(&(*pp)->left, v);
    else {
        if (((*pp)->val[0] < v) && ((*pp)->val[1] > v))
            (*pp)->center = Insert(&(*pp)->center, v);
        else (*pp)->right = Insert(&(*pp)->right, v);
    }
    return (*pp);
}

void Round(struct tree *root, int lev, int n) { // tree traversal function from top to bottom and from left to right; the result is an ordered numeric sequence

    if (root == NULL) return;
    if (root->val[0] == 12){
        printf("           ");
        printf(" %d ", root->val[0]);
        if (root->val[1] == 0) printf(" NULL\n");
        else printf(" %d\n", root->val[1]);
    }

    if (root->left != NULL){

        n++;
        printf(" %d ", root->left->val[0]);
        if (root->left->val[1] == 0) printf(" NULL   ");
        else printf(" %d   ", root->left->val[1]);

    }
    if (root->center != NULL){

        n++;
        printf(" %d ", root->center->val[0]);
        if (root->center->val[1] == 0) printf(" NULL   ");
        else printf(" %d   ", root->center->val[1]);

    }
    if (root->right != NULL){

        n++;
        printf(" %d ", root->right->val[0]);
        if (root->right->val[1] == 0) printf(" NULL   ");
        else printf(" %d   ", root->right->val[1]);
    }

    if (n == lev){
        printf("\n");
        n = 0;
        lev*=3;
    }
    if ((root->left) != NULL) Round(root->left, lev, n);
    if ((root->center) != NULL) Round(root->center, lev, n);
    if ((root->right) != NULL) Round(root->right, lev, n);

}


int Choice() { // selection function: add a new number or exit the program
    int ans;
    printf("\n\nDo you want to add new number?\n[1] Yes \n[0] No \nEnter the number of your choice: ");
    scanf("%d", &ans);
    return ans;
}

struct tree* FirstTree(struct tree *root) { // creating the start tree function

    root->val[0] = 12; root->val[1] = 24;
    root->left = root->right = root->center = NULL;
    Insert(&root, 6);
    Insert(&root, 13);
    Insert(&root, 17);
    Insert(&root, 25);
    Insert(&root, 27);
    printf("\n          START TREE:\n \n");
    Round(root, 3, 0);// displaying the start tree
    return root;
}

void Add(struct tree *root) { // adding new elements to the tree function
    if (Choice()) {
        int a;
        printf("\nEnter integer number for insert in tree (not 0) = ");
        scanf("%d", &a);
        Insert(&root, a);
        printf("\n           NEW TREE:\n \n");
        Round(root, 3, 0); // output to the console of the tree with the new element
        Add(root);
    }
}

int main(void) {

    struct tree *root = (struct tree*)malloc(sizeof(struct tree)); // creating the root of the tree
    root = FirstTree(root); // creating the start tree
    Add(root); // adding new elements to the tree
    return 0;
}