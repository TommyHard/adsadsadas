#include <stdio.h>
#include <malloc.h>

struct tree { 
  int val[2];
  struct tree *left, *center, *right;
};

struct tree* AddTreeLeaf(int v) { // function to create a new leaf of the tree  
    struct tree *tmp = (struct tree*)malloc(sizeof(struct tree));
    tmp->left = tmp->right = tmp->center = NULL;
    tmp->val[0] = v; tmp->val[1] = 0;
    return tmp;
}

struct tree* InsertValue(struct tree **pp, int v) { // function of inserting an element into a tree while maintaining the tree order 
  if ((*pp) == NULL) { // creating a new leaf of the tree
    (*pp) = AddTreeLeaf(v);
    return(*pp);
  }
  if ((v == (*pp)->val[0]) || (v == (*pp)->val[1])) {
    printf("\n --- Do not enter the number that already here --- \n");
    return (*pp);
  }
  if ((v > (*pp)->val[0]) && ((*pp)->val[0]) && ((*pp)->val[1] == 0)) {
    (*pp)->val[1] = v; 
    return (*pp); // the second number is added to the leaf of the tree  
  } 
  /* recursive search for the insertion point of an element */
  if ((*pp)->val[0] > v)
    (*pp)->left = InsertValue(&(*pp)->left, v);
  else {
    if (((*pp)->val[0] < v) && ((*pp)->val[1] > v))
      (*pp)->center = InsertValue(&(*pp)->center, v);
    else (*pp)->right = InsertValue(&(*pp)->right, v);
  }
  return (*pp);
}

int ScanTree(struct tree *root, int level, int n) { // tree traversal function from top to bottom and from left to right; the result is an ordered numeric sequence 
  if (root == NULL) return n;

  if (root->val[0] == 12) {
    printf("\n");
    for (int i = 4; i > 0; i--) printf("   ");
    printf(" %d", root->val[0]);
    if (root->val[1] == 0) printf(" NULL\n");
    else printf(" %d\n", root->val[1]);
  }

  if ((root->left) != NULL) {
    n++;
    printf("   ");  
    printf(" %d", (root->left)->val[0]);
    if ((root->left)->val[1] == 0) printf(" NULL");
    else printf(" %d", (root->left)->val[1]);
  }

  if ((root->center) != NULL) {
    n++;
    printf("   ");
    printf("%d", (root->center)->val[0]);
    if ((root->center)->val[1] == 0) printf(" NULL");
    else printf(" %d", (root->center)->val[1]);
  }

  if ((root->right) != NULL) {
  n++;
  printf("   ");
  printf("%d", (root->right)->val[0]);
  if ((root->right)->val[1] == 0) printf(" NULL");
  else printf(" %d", (root->right)->val[1]);
  }

  if (n == level) {
    printf("\n");
    level *= 3;
    n = 0;
  }

  if ((root->left) != NULL) n = ScanTree(root->left, level, n);
  if ((root->center) != NULL) n = ScanTree(root->center, level, n);
  if ((root->right) != NULL) n = ScanTree(root->right, level, n);
  return n;
}

void ClearScreen() { // console purge function 
  #if(windows)
  system("cls");
  #else
  system("clear");
  #endif
}

int Choice() { // selection function: add a new number or exit the program 
  int ans;
  printf("\n\nDo you want to add new number?\n[1] Yes \n[0] No \n-> Enter the number of your choice = ");
  scanf("%d", &ans);
  return ans;
}

struct tree* StartTree(struct tree *root) { // creating the start tree function
  root->val[0] = 12; root->val[1] = 24;
  root->left = root->right = root->center = NULL;
  InsertValue(&root, 6);
  InsertValue(&root, 13);
  InsertValue(&root, 17);
  InsertValue(&root, 25);
  InsertValue(&root, 27);
  printf("\n\n          START TREE"); ScanTree(root, 3, 0); // displaying the start tree
  return root;
}

void AddNum(struct tree *root) { // adding new elements to the tree function
  if (Choice()) {
    int v;
    printf("\n-> Enter integer number for insert in tree (not 0) = ");
    scanf("%d", &v); 
    InsertValue(&root, v);
    printf("\n\n            NEW TREE"); ScanTree(root, 3, 0); // output to the console of the tree with the new element
    AddNum(root);
  } 
}

int main(void) {
  ClearScreen();
  struct tree *root = (struct tree*)malloc(sizeof(struct tree)); // creating the root of the tree
  root = StartTree(root); // creating the start tree
  AddNum(root); // adding new elements to the tree
  return 0;
}