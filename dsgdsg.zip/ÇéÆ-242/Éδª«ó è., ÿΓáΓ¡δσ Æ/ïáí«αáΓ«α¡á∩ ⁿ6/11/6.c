#include <stdio.h>
#include <string.h>
#include <malloc.h>
#define N 4

typedef struct TREE{
	int cnt;
	int a[N];
	struct TREE *l,*r;
	} tree;


tree * create(int *ss)
{
	tree * q = malloc(sizeof(tree));
	q->l = q->r = NULL;
	q->cnt = 1;
	for (int i=0;i<N;i++)
	q->a[i] = ss[i];
	for (int i=0;i<N;i++)

	for (int i=0;i<N;i++)


	return q;
}

tree *get_n(tree *p, int n){
	if (p==NULL) return NULL;
	if (n >= p->cnt) return NULL;
	if (p->l!=NULL){
		int ll=p->l->cnt;
		if (n<ll) return get_n(p->l,n);
		n-=ll;
		}
	if (n-- ==0) return p;
	return get_n(p->r,n);
	}


tree* insert(tree * p, int n, int *ss)
{
	if (p == NULL) { return create(ss); }
	if (n >= p->cnt) return p;
	p->cnt++;
	if (p->l!=NULL){
		int ll=p->l->cnt;
		if (n<ll) { p->l = insert(p->l,n,ss); return p; }
		n-=ll;
		}
	if (n-- ==0) {
		if (p->l==NULL)
			p->l=create(ss);
		else  { p->r = insert(p->r,0,p->a);
		for (int i=0;i<N;i++)
				p->a[i]=ss[i];
		}}
	else p->r = insert(p->r,n,ss);
}




tree* add(tree * p, int ss[]){
	if (p==NULL) { return create(ss);}
	else
        {p->cnt++; p->r = add(p->r, ss);return p;}

	}


void scan(tree *p, int level, int* ln)
{

	if (p==NULL) return ;
	scan(p->l, level+1,ln);
	printf("l=%d n=%d cnt=%d :", level, *ln, p->cnt);
	for (int i=0;i<N;i++)
        printf("%d",p->a[i]);
    printf("\n");
	(*ln)++;
	scan(p->r, level+1,ln);
}



tree *balance(tree *pp[], int a, int b){

	if (a>b) {

            return NULL;}
	tree *q;
	if (a==b) { q=pp[a]; q->l=q->r=NULL; q->cnt=1;
	return q; }
	int m=(a+b)/2;
	q=pp[m];
	q->l=balance(pp,a,m-1);
	q->r=balance(pp,m+1,b);
	q->cnt=b-a+1;
	return q;
	}


void set(tree *pp[], tree *p, int *ln){
    if (p!=NULL)
        ;
    else
	if (p==NULL) return;
	set(pp,p->l,ln);
	pp[*ln]=p;
	*ln =*ln+1;
	set(pp,p->r,ln); }

tree* balance_tree(tree * ph){
	int sz=ph->cnt;
	tree ** pp= malloc(sz*sizeof(tree*));
	int ln=0;
	set(pp,ph,&ln);
	ph=balance(pp,0,sz-1);
	return ph;
	}

int main(){
tree * ph=NULL;
int k=0;
int a[N]={1,2,3,5};
int b[N]={5,2,1,1};
int c[N]={2,2,3,5};
ph = add(ph,a);
ph = add(ph,b);
ph = add(ph,a);
ph = add(ph,b);
ph = add(ph,c);
ph = add(ph,c);
if (ph==NULL)
printf("ph==NULL\n");
k=0;
printf("scan before balance\n");
scan(ph,1,&k);
printf("balance\n");
ph = balance_tree(ph);
k=0;
printf("scan after balance\n");
scan(ph,1,&k);
int d[N]={4,4,4,4};
printf("insert\n");
insert(ph,3,d);
insert(ph,6,d);
insert(ph,1,a);
k=0;
scan(ph,1,&k);
tree* finded =get_n(ph,8);
printf("cnt = %d\n",finded->cnt);
printf("finded:");
for (int i = 0;i<N;i++)
    printf("%d",finded->a[i]);
finded =get_n(ph,4);
printf("\ncnt = %d\n",finded->cnt);
printf("finded:");
for (int i = 0;i<N;i++)
    printf("%d",finded->a[i]);

finded =get_n(ph,3);
printf("\ncnt = %d\n",finded->cnt);
printf("finded:");
for (int i = 0;i<N;i++)
    printf("%d",finded->a[i]);
}



