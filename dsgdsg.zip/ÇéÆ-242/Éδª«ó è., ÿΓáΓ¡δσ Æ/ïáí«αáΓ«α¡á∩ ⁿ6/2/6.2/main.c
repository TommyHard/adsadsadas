#include <string.h>
#include <stdio.h>
#include <malloc.h>

typedef struct Node {
    char word[100];
    struct Node *l, *r;
} Node;

void show(struct Node *Tree) {
    if (Tree != NULL) {
        show(Tree->l);
        if (Tree->word[0] != '*')
            printf("%s\n", Tree->word);
        show(Tree->r);
    }
}

void reading_file_struct(char **buf, int n, char *list) {
    FILE *fp;
    if ((fp = fopen(list, "r")) == NULL) {
        printf("Cannot open a file\n");
        exit(-1);
    }

    for (int i = 0; i < n; ++i) {
        fscanf(fp, "%s", buf[i]);
    }
    fclose(fp);
}

// функция начальной инициализации потомков
void to_null(Node *MyTree) {
    MyTree->r = MyTree->l = NULL;
}

Node *create(char *str1, char *str2) {
    Node *MyTree = (Node *) malloc(sizeof(struct Node));
    strcpy(MyTree->word, "*");
    MyTree->l = (Node *) malloc(sizeof(struct Node));
    strcpy(MyTree->l->word, str1);
    to_null(MyTree->l);
    MyTree->r = (Node *) malloc(sizeof(struct Node));
    strcpy(MyTree->r->word, str2);
    to_null(MyTree->r);
    return MyTree;
}

int add_node(char *word, Node *MyTree, int *cur_c, int *c) {
    if (MyTree == NULL) {
        return 0;
    }
    if (strcmp(MyTree->word, "*") != 0) {
        (*cur_c)++;
        if (strcmp(MyTree->word, word) > 0) {
            MyTree->l = (Node *) malloc(sizeof(struct Node));
            MyTree->r = (Node *) malloc(sizeof(struct Node));
            strcpy(MyTree->l->word, word);
            strcpy(MyTree->r->word, MyTree->word);
            strcpy(MyTree->word, "*");
            to_null(MyTree->l);
            to_null(MyTree->r);
            return 1;
        }

        if (*c == *cur_c) {
            MyTree->l = (Node *) malloc(sizeof(struct Node));
            MyTree->r = (Node *) malloc(sizeof(struct Node));
            strcpy(MyTree->r->word, word);
            strcpy(MyTree->l->word, MyTree->word);
            strcpy(MyTree->word, "*");
            to_null(MyTree->l);
            to_null(MyTree->r);
            return 1;
        }
    }
    if (!add_node(word, MyTree->l, cur_c, c)) {
        if (add_node(word, MyTree->r, cur_c, c)) return 1;
        else return 0;
    } else return 1;
}

int main() {

    //буферный массив для строк
    int n = 10, m = 100;
    char **buf = (char **) malloc(n * sizeof(char *));
    for (int i = 0; i < n; i++)
        buf[i] = (char *) malloc(m * sizeof(char));

    char **rbuf = (char **) malloc(2 * sizeof(char *));
    for (int i = 0; i < 2; i++)
        rbuf[i] = (char *) malloc(m * sizeof(char));

    int N = 6;
    reading_file_struct(rbuf, 2, "read.txt");
    reading_file_struct(buf, N, "read2.txt");

    struct Node *Tree = create(rbuf[0], rbuf[1]);

    // счетчики для для крайнего случая
    int cur_c = 0, c = 2;
    for (int i = 0; i < N; i++) {
        add_node(buf[i], Tree, &cur_c, &c);
        cur_c = 0;
        c++;
    }
    printf("default tree (from file):\n");
    show(Tree);

    char new_name[100];
    printf("\nEnter new name: ");
    gets(new_name);
    add_node(new_name, Tree, &cur_c, &c);

    printf("\nTree:\n");
    show(Tree);

    return 0;
}