﻿#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <iostream>

#define MaxSize 50

typedef struct NumbersToCode NumbersToCode;
typedef struct Tree Tree;

void Search(Tree Node, NumbersToCode* Codes);

struct Tree
{
    char Symbols[MaxSize]; // Значения вершины дерева
    int Frequency; // Частота появления символа
    struct Tree* Parent;
    struct Tree* LeftChild;
    struct Tree* RightChild;
};

struct NumbersToCode
{
    char Symbol;
    char Code[10];
    int Count; // Частота появления в строке
};

int InputString(char** String)
{
    int Size = 30;
    char Command = ' ';
    int i = -1;
    int j = 1;
    *String = (char*)malloc(Size * sizeof(char));
    //
    printf("Введите последовательность:\n");
    //
    while (1)
    {
        if (i + 2 == j * Size)
        {
            j++;
            (*String) = (char*)realloc(*String, j * Size * sizeof(char));
        }
        //
        scanf("%c", &Command);
        //
        if (Command == '\n')
        {
            (*String)[i + 1] = '\0';
            //
            break;
        }
        //
        i++;
        (*String)[i] = Command;
    }
    int _Size = i + 1;
    //
    return _Size;
}

// Подсчитываем частоту
Tree** FrequencyCalculation(char* Input, int Size, int* TreeSize)
{
    Tree** Frequency = (Tree**)malloc(sizeof(Tree*));
    *TreeSize = -1;
    //
    while (Size > 0)
    {
        int Count = 1;
        char Symbol = Input[0];
        int i = 1;
        //
        while (Input[i] != '\0')
        {
            if (Input[i] == Input[0])
            {
                for (int j = i; j <= Size - 1; j++)
                {
                    Input[j] = Input[j + 1];
                }
                //
                Count++;
            }
            else
            {
                i++;
            }
        }
        for (int j = 0; j < Size; j++)
        {
            Input[j] = Input[j + 1];
        }
        //
        (*TreeSize)++;
        //
        Frequency = (Tree**)realloc(Frequency, (*TreeSize + 1) * sizeof(Tree*));
        Frequency[*TreeSize] = (Tree*)malloc(sizeof(Tree));
        Frequency[*TreeSize]->Symbols[0] = Symbol;
        Frequency[*TreeSize]->Symbols[1] = '\0';
        Frequency[*TreeSize]->Frequency = Count;
        Frequency[*TreeSize]->LeftChild = NULL;
        Frequency[*TreeSize]->RightChild = NULL;
        //
        Size -= Count;
    }
    //
    return Frequency;
}

Tree* CreateTree(Tree** Frequency, int Size)
{
    Tree* Code{};
    //
    if (Size == 0)
    {
        return (Frequency[Size]);
    }
    //
    int i = -1;
    //
    while (Size > 0)
    {
        i++;
        Tree* Temp = (Tree*)malloc(sizeof(Tree));
        //
        int Temp1 = 10;
        int Temp2 = 10;
        int Temp3 = -1;
        int Temp4 = -1;
        //
        for (int j = 0; j <= Size; j++)
        {
            if (Frequency[j]->Frequency < Temp1)
            {
                Temp3 = j;
                Temp1 = Frequency[j]->Frequency;
            }
        }
        //
        for (int j = 0; j <= Size; j++)
        {
            if ((Frequency[j]->Frequency < Temp2) && (Frequency[j] != Frequency[Temp3]))
            {
                Temp4 = j;
                Temp2 = Frequency[j]->Frequency;
            }
        }
        //
        Temp->Frequency = Frequency[Temp3]->Frequency + Frequency[Temp4]->Frequency;
        Temp->LeftChild = Frequency[Temp3];
        Frequency[Temp3]->Parent = Temp;
        Temp->RightChild = Frequency[Temp4];
        Frequency[Temp4]->Parent = Temp;
        //
        int j = 0;
        int k = -1;
        //
        while (Frequency[Temp3]->Symbols[j] != '\0')
        {
            Temp->Symbols[++k] = Frequency[Temp3]->Symbols[j++];
        }
        //
        j = 0;
        //
        while (Frequency[Temp4]->Symbols[j] != '\0')
        {
            Temp->Symbols[++k] = Frequency[Temp4]->Symbols[j++];
        }
        //
        Temp->Symbols[++k] = '\0';
        Frequency[Temp4] = Temp;
        //
        for (int h = Temp3; h < Size; h++)
        {
            Frequency[h] = Frequency[h + 1];
        }
        //
        Size--;
        //
        if (Size == 0)
        {
            Code = Temp;
        }
    }
    //
    return (Code);
}

NumbersToCode* CreateCode(Tree* Tree, int TreeSize)
{
    int i = -1;
    NumbersToCode* Codes = (NumbersToCode*)malloc(sizeof(NumbersToCode));
    //
    if (TreeSize == 0)
    {
        Codes[0].Symbol = Tree->Symbols[0];
        Codes[0].Code[0] = '0';
        Codes[0].Code[1] = '2';
        //
        return (Codes);
    }
    //
    while (TreeSize >= 0)
    {
        i++;
        Codes = (NumbersToCode*)realloc(Codes, (i + 1) * sizeof(NumbersToCode));
        Codes[i].Symbol = 0;
        Codes[i].Count = -1;
        //
        Search(*Tree, &Codes[i]);
        //
        TreeSize--;
    }
    //
    return Codes;
}

void Search(Tree Node, NumbersToCode* Codes)
{
    if (Node.LeftChild != NULL)
    {
        Codes->Count++;
        Codes->Code[Codes->Count] = '0';
        //
        Search(*Node.LeftChild, Codes);
    }
    //
    if (Codes->Symbol != 0)
    {
        return;
    }
    //
    if (Node.RightChild != NULL)
    {
        Codes->Count++;
        Codes->Code[Codes->Count] = '1';
        //
        Search(*Node.RightChild, Codes);
    }
    //
    if (Codes->Symbol != 0)
    {
        return;
    }
    //
    if (Node.Symbols[1] == '\0')
    {
        Codes->Symbol = Node.Symbols[0];
        Codes->Code[Codes->Count + 1] = '2';
    }
    else
    {
        Codes->Count--;
    }
    //
    if ((Node.Parent->LeftChild != NULL) && (Node.Parent->LeftChild->Symbols[0] == Node.Symbols[0]))
    {
        Node.Parent->LeftChild = NULL;
    }
    else if ((Node.Parent->RightChild != NULL) && (Node.Parent->RightChild->Symbols[0] == Node.Symbols[0]))
    {
        Node.Parent->RightChild = NULL;
    }
}

void main()
{
    setlocale(LC_ALL, "Russian");
    //
    char* String1;
    int Size = InputString(&String1);
    char* String2 = (char*)malloc(Size * sizeof(char));
    //
    for (int i = 0; i <= Size; i++)
    {
        String2[i] = String1[i];
    }
    int TreeSize;
    //
    Tree** freq = FrequencyCalculation(String1, Size, &TreeSize);
    //
    printf("\nСимволы и их частота появления:\n");
    //
    for (int i = 0; i <= TreeSize; i++)
    {
        printf("%c - %d\n", freq[i]->Symbols[0], freq[i]->Frequency);
    }
    //
    printf("\n");
    //
    Tree* code = CreateTree(freq, TreeSize);
    NumbersToCode* codes = CreateCode(code, TreeSize);
    //
    printf("Символы и их коды:\n");
    //
    for (int i = 0; i <= TreeSize; i++)
    {
        printf("%c - ", codes[i].Symbol);
        //
        int j = 0;
        //
        while (codes[i].Code[j] < '2')
        {
            printf("%c", codes[i].Code[j]);
            //
            j++;
        }
        //
        printf("\n");
    }
    //
    printf("\nКод Хаффмана:\n");
    //
    for (int i = 0; i <= Size; i++)
    {
        for (int j = 0; j <= TreeSize; j++)
        {
            if (String2[i] == codes[j].Symbol)
            {
                int k = 0;
                //
                while (codes[j].Code[k] != '2')
                {
                    printf("%c", codes[j].Code[k]);
                    //
                    k++;
                }
            }
        }
        //
        printf(" ");
    }
    //
    printf("\n");
}