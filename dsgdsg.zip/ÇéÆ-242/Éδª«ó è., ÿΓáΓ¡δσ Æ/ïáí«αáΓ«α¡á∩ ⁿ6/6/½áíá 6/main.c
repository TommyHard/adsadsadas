#include <stdio.h>
#include <stdlib.h>

#define N 2

struct node {

    int arr[N];

    int cnt;
    int arr_cnt;
    struct node *left;
    struct node *right;

};

void preorder(struct node *root) {
    if (root == NULL)
        return;
    for (int i = 0; i < N; ++i) {
        printf("%d\t", root->arr[i]);
    }
    printf("\n");
    preorder(root->left);
    preorder(root->right);
}

struct node *insert(struct node *p, int v) {

    if (p == NULL) {
        p = (struct node *) malloc(sizeof(struct node));
        for (int i = 0; i < N; ++i) {
            p->arr[i] = -1;
        }
        p->left = p->right = NULL;
        p->cnt = 1;
        p->arr[0] = v;
        p->arr_cnt = 1;
        return p;
    }

    p->cnt++;

    if (p->arr_cnt < N) {
        p->arr[p->arr_cnt] = v;
        p->arr_cnt++;

        return p;

    } else {

        int max = p->arr[0];
        int ind_max = 0;

        for (int i = 0; i < N; ++i) {
            if (p->arr[i] > max) {
                ind_max = i;
                max = p->arr[i];
            }
        }

        if (max > v) {                        // Вытеснение меньшим значением большего
            int c = v;
            v = p->arr[ind_max];
            p->arr[ind_max] = c;
        }
    }


    if (p->left == NULL || p->right != NULL && p->left->cnt < p->right->cnt) {
        p->left = insert(p->left, v);
    } else {
        p->right = insert(p->right, v);
    }
    return p;
}


int main() {

    struct node tree;
    tree.cnt = 0;
    tree.arr_cnt = 0;
    tree.left = NULL;
    tree.right = NULL;
    int numbers[29] = {111, 92, 84, 78, 63, 59, 42, 33, 25, 17, 8, 19, 32, 37, 38, 46, 47, 51, 54, 55, 59, 67, 69, 70, 72, 82, 93, 95, 100};

    for (int i = 0; i < N; ++i) {
        tree.arr[i] = -1;
    }

    for (int i = 0; i < 29; ++i) {

        insert(&tree, numbers[i]);
    }
    preorder(&tree);

    return 0;
}
