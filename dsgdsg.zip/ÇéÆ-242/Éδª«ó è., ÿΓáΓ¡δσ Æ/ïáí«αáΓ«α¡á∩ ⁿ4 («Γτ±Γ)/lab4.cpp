﻿#include <stdio.h>
#include <malloc.h>
#include <locale.h>

#define FilePath "lab4_Quotes.txt"

/*
* #14
* Элемент односвязного списка содержит массив указателей на строки.
* Функция создает структуру данных, читает из файла строки и заполняет ее, пока файл не кончится.
* (В конце последнего МУ записывается NULL-указатель).
*/

// Структура списка
struct List
{
    char** CurrentString;
    struct List* NewString;
};

// Функция создания структуры
List* CreateList(char** NewString)
{
    List* _List;
    _List = (struct List*)malloc(sizeof(struct List));
    _List->CurrentString = NewString;
    _List->NewString = NULL;
    //
    return _List;
}

// Добавляем структуру в конец
void GetPreviousString(List** _List, char** UpdateString)
{
    List* GetNextString = CreateList(UpdateString);
    List* Temp = *_List;
    //
    while (Temp->NewString != NULL)
    {
        Temp = Temp->NewString;
    }
    //
    Temp->NewString = GetNextString;
}

// Читаем строки из файла
int LoadFromFile(char** Buffer)
{
    FILE* LocalFile;
    //
    int NumberOfLines = 0;
    int NumberOfCharacters = 0;
    //
    if ((LocalFile = fopen(FilePath, "r")) != NULL)
    {
        while (1)
        {
            int Symbol = fgetc(LocalFile);
            //
            if (Symbol == EOF)
            {
                if (feof(LocalFile) != 0)
                {
                    break;
                }
                else
                {
                    printf(">>\033[31m Нет данных для чтения \033[0m\n");
                    //
                    break;
                }
            }
            if (Symbol != '\n')
            {
                Buffer[NumberOfLines][NumberOfCharacters++] = Symbol;
            }
            else
            {
                Buffer[NumberOfLines++][NumberOfCharacters] = '\0';
                NumberOfCharacters = 0;
            }
        }
    }
    else
    {
        printf(">>\033[31m Нет данных для чтения \033[0m\n");
    }
    //
    return NumberOfLines;
}

void ShowInformation(struct List* _List)
{
    while (_List->NewString != NULL)
    {
        printf("\033[36m %s\033[0m\n", *(_List->CurrentString));
        //
        _List = _List->NewString;
    }
}

void main()
{
    setlocale(LC_ALL, "Russian");
    //
    char** Buffer;
    int Strings = 20; // Кол-во строк
    int Line = 70; // Длина строки
    //
    Buffer = (char**)malloc(Strings * sizeof(char*));
    //
    for (int i = 0; i < Strings; i++)
    {
        Buffer[i] = (char*)malloc(Line * sizeof(char));
    }
    //
    int NumberOfLines = LoadFromFile(Buffer);
    //
    if (NumberOfLines > 0)
    {
        struct List* _List = CreateList(&Buffer[0]);
        //
        for (int i = 1; i < NumberOfLines; i++)
        {
            GetPreviousString(&_List, &Buffer[i]);
        }
        //
        ShowInformation(_List);
    }
    else
    {
        printf(">>\033[31m Читаемый файл пуст \033[0m\n");
    }
}