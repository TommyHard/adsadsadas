﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <locale>
#include <cstring>
#include <fstream>
#include <algorithm>
#include <string>

using namespace std;

/* #10
* Программа генерирует текст из строки, содержащей определения циклических фрагментов вида 
...(Иван,Петр,Федор=Жил-был * (синего,белого,желтого= у самого * моря)).... 
Символ «*» определяет место подстановки имени из списка в очередное повторение фрагмента. 
Допускается вложенность фрагментов. Полученный текст помещается в выходную строку.
*/

void parseString(char* InputArray, char**& Array, int& count)
{
    int Length = strlen(InputArray);
    char* Temp = new char[Length + 1];
    int k = 0;
    count = 0;
    //
    for (int i = 0; i < Length; i++)
    {
        if (InputArray[i] == '(')
        {
            i++;
            //
            while (InputArray[i] != ')' && InputArray[i] != '(')
            {
                Temp[k++] = InputArray[i++];
            }
            //
            Temp[k] = '\0';
            Array[count++] = Temp;
            Temp = new char[Length + 1];
            k = 0;
            i--;
        }
    }
    //
    delete[] Temp;
}

string replaceStar(char Input[], int How)
{

    char* Copy = new char[1000];
    strcpy(Copy, Input);
    //
    char* Ptr = strtok(Copy, "=,*");
    char* names[3];
    //
    string Temp;
    //
    int i = 0;
    int Position;
    //
    while (Ptr)
    {
        if (i < 3)
        {
            names[i] = Ptr;
        }
        else
        {
            Temp = Ptr;
            Position = Temp.find('*');
            //
            if (How == 0)
            {
                Temp.insert(Position + 1, names[0]);
                Temp.erase(Position, 1);
                //
                return Temp;
            }
            else if (How == 1)
            {
                Temp.insert(Position + 1, names[1]);
                Temp.erase(Position, 1);
                //
                return Temp;
            }
            else
            {
                Temp.insert(Position + 1, names[2]);
                Temp.erase(Position, 1);
                //
                return Temp;
            }
            //
            char* text1 = Ptr;
            i++;
            //
            break;
        }
        //
        Ptr = strtok(NULL, "=,");
        i++;
    }
}

void removeExtraSpaces(string& Input)
{
    Input = string(find_if(Input.begin(), Input.end(), [](int ch)
        {
            return !isspace(ch);
        }), find_if(Input.rbegin(), Input.rend(), [](int ch)
            {
                return !isspace(ch);
            }).base());
    auto newEnd = unique(Input.begin(), Input.end(), [](int l, int r)
        {
            return isspace(l) && isspace(r);
        });
    //
    Input.erase(newEnd, Input.end());
}

void removeExtraSpacesFromFile(const string& FileName)
{
    ifstream fileIn(FileName);
    //
    if (!fileIn)
    {
        cerr << "Не удалось открыть файл для чтения: " << FileName << endl;
        //
        return;
    }
    //
    string tmpFilename = "output.txt";
    ofstream fileOut(tmpFilename);
    //
    if (!fileOut)
    {
        cerr << "Не удалось открыть файл для записи: " << tmpFilename << endl;
        //
        return;
    }
    //
    string Line;
    //
    while (getline(fileIn, Line))
    {
        removeExtraSpaces(Line);
        fileOut << Line << '\n';
    }
    //
    fileIn.close();
    fileOut.close();
    //
    remove(FileName.c_str());
    rename(tmpFilename.c_str(), FileName.c_str());
}

void clearFile(const string& FileName)
{
    ofstream file(FileName);
    //
    if (!file)
    {
        cerr << "Не удалось открыть файл для записи: " << FileName << endl;
        //
        return;
    }
    //
    file << "";
    file.close();
}

void main()
{
    setlocale(LC_ALL, "Russian");
    //
    char Victim[] = "(Иван,Петр,Федор=Жил-был * (синего, белого, черного = у самого * моря(казахстане, парабели, барнауле = в *)))";
    //
    const int MAX_STRINGS = 10;
    char** Array = new char* [MAX_STRINGS];
    int Count = 0;
    //
    parseString(Victim, Array, Count);
    //
    ofstream outfile1("text1.txt", ios::app);
    ifstream infile1("text1.txt");
    //
    ofstream outfile2("text2.txt", ios::app);
    ifstream infile2("text2.txt");
    //
    string Temp;
    //
    for (int i = 0; i < Count; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (i == 0)
            {
                outfile1 << replaceStar(Array[i], j) << endl;
            }
            else if (i % 2 == 0)
            {
                while (getline(infile2, Temp))
                {
                    for (int g = 0; g < 3; g++)
                    {
                        outfile1 << Temp << replaceStar(Array[i], g) << endl;
                    }
                    //
                    clearFile("text2.txt");
                }
            }
            else
            {
                while (getline(infile1, Temp))
                {
                    for (int g = 0; g < 3; g++)
                    {
                        outfile2 << Temp << replaceStar(Array[i], g) << endl;
                    }
                    //
                    clearFile("text1.txt");

                }
            }
            //
            outfile1.clear();
            outfile2.clear();

        }
    }
    //
    infile1.clear();
    infile2.clear();
    //
    ifstream out("output.txt");
    //
    if (Count % 2)
    {
        removeExtraSpacesFromFile("text1.txt");
    }
    else
    {
        removeExtraSpacesFromFile("text2.txt");
    }
    //
    while (getline(out, Temp))
    {
        cout << Temp << endl;
    }
    //
    outfile1.close();
    outfile2.close();
    //
    for (int i = 0; i < Count; i++)
    {
        delete[] Array[i];
    }
    //
    delete[] Array;
    //
    clearFile("text1.txt");
    clearFile("text2.txt");
    clearFile("output.txt");
}
