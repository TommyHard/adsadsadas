#include <stdio.h>

int compare_int(const int *p1, const int *p2) {

    while (1) {
        if ((*p1) > (*p2)) {
            return 0;
        } else return 1;
    }
}

int compare_double(const double *p1, const double *p2) {

    while (1) {
        if ((*p1) > (*p2)) {
            return 0;
        } else return 1;
    }
}

int compare_char(const char *p1, const char *p2) {

    while (1) {
        if ((*p1) > (*p2)) {
            return 0;
        } else return 1;
    }
}

void bubbleSort(void *arr, int n, void (*swap_func)(void *, void *), int mode) {
    int i, j;

    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - i - 1; j++) {
            switch (mode) {
                case 1:
                    if (compare_int(&((int *) arr)[j], &((int *) arr)[j + 1]) == 0) {
                        swap_func(&((int *) arr)[j], &((int *) arr)[j + 1]);
                    }
                    break;

                case 2:
                    if (compare_double(&((double *) arr)[j], &((double *) arr)[j + 1]) == 0) {
                        swap_func(&((double *) arr)[j], &((double *) arr)[j + 1]);
                    }
                    break;

                case 3:
                    if (compare_char(&((char *) arr)[j], &((char *) arr)[j + 1]) == 0) {
                        swap_func(&((char *) arr)[j], &((char *) arr)[j + 1]);
                    }
                    break;

                default:
                    break;
            }
        }

    switch (mode) {
        case 1:
            for (int k = 0; k < n; ++k) {
                printf("%d ", ((int *) arr)[k]);
            }
            break;

        case 2:
            for (int z = 0; z < n; ++z) {
                printf("%.2f ", ((double *) arr)[z]);
            }
            break;

        case 3:
            for (int p = 0; p < n; ++p) {
                printf("%c ", ((char *) arr)[p]);
            }
            break;

        default:
            break;
    }
}

void swap_int(int *p1, int *p2) {
    int tmp;


    tmp = *p1;
    *p1 = *p2;
    *p2 = tmp;
}

void swap_double(double *p1, double *p2) {
    double tmp;
    tmp = *p1;
    *p1 = *p2;
    *p2 = tmp;
}

void swap_char(void *p1, void *p2) {
    char *pp1, *pp2, tmp;

    pp1 = (char *) p1;
    pp2 = (char *) p2;

    tmp = *pp1;
    *pp1 = *pp2;
    *pp2 = tmp;
}

int main() {

    int ar1[] = {1, 5, 2, 3, 666};
    int n1 = sizeof(ar1) / sizeof(ar1[0]);

    double ar2[] = {1.1, 5.5, 2.2, 3.3, 8.8};
    int n2 = sizeof(ar2) / sizeof(ar2[0]);

    char str[] = {'A', 'H', 'L', 'P', 'Z', 'B', 'G'};
    int n3 = sizeof(str) / sizeof(str[0]);

    bubbleSort(ar1, n1, (void (*)(void *, void *)) swap_int, 1);
    printf("\n");
    bubbleSort(ar2, n2, (void (*)(void *, void *)) swap_double, 2);
    printf("\n");
    bubbleSort(str, n3, (void (*)(void *, void *)) swap_char, 3);

    return 0;
}

