#include <stdio.h>
#include <malloc.h>

struct list
{
  int val; 
  struct list *next;
  struct list *prev;
};

struct tree
{
  int val[2];
  struct tree *left;
  struct tree *center;
  struct tree *right; 
};

void listprint(struct list *lst) { // list display function
  printf("Sorted list: \n");
  struct list *p;
  p = lst;
  while (p!= NULL)
   { 
    printf("%d ", p->val); 
    p = p->next;  // go to the end of the list
   } // loop to display the list as usual
  printf("\nSorted list IN REVERSE ORDER: \n");
  p = lst;
  while (p->next != NULL)
    p = p->next;  
  do {
    printf("%d ", p->val); 
    p = p->prev; 
  } while (p != NULL); 
}

void add(struct list **lst, int number) // creating a new list item function
{
  if ((*lst) == NULL)
   { // creating the first element of the list
    (*lst) = (struct list*)malloc(sizeof(struct list));
    (*lst)->next = NULL;
    (*lst)->val = number;
    (*lst)->prev = NULL;
   }
  else
   { // creating a new list item
    struct list *p = *lst;
    while (p->next != NULL)
      p = p->next; 
    struct list *temp = (struct list*)malloc(sizeof(struct list));
    temp->val = number;
    temp->prev = p;
    temp->next = NULL;
    p->next = temp;
  }
}

void* arr_first(void *in) // first element of array
{
  return (int*)in + 1;
}

void* arr_last(void *in) // last element of array
{
  return (int*)(in)+*(int*)in;
}

void* arr_next(void *in) // next element of array
{
  return (void*)((int*)(in) + 1);
}

int arr_cmp(void *first, void *second) // compairing two elements of array function
{
  return *(int*)first - *(int*)second > 0 ? 1 : -1;
}

void arr_swap(void *first, void *second) // swapping two elements of array function
{
  int temp = *(int*)first;
  *(int*)first = *(int*)second;
  *(int*)second = temp;
}

void* arr_perv(void *in) // previous element of array
{
  return (void*)((int*)(in)-1);
}

void* list_first(void *in) // first element of list
{
  return (struct list*)in;
}

void* list_last(void *in) // last element of list
{
  struct list *temp = (struct list*)in;
  while (((struct list*)in)->next != NULL) in = ((struct list*)in)->next;
  temp = (struct list*)in;
  while (((struct list*)in)->prev != NULL) in = ((struct list*)in)->prev;
  return temp;
}

void *list_next(void *in) // next element of list
{
  return ((struct list*)in)->next;
}

int list_cmp(void *first, void *second) // compairing two elements of list function
{
  return ((struct list*)first)->val - ((struct list*)second)->val > 0 ? 1 : -1;
}

void list_swap(void *first, void *second) // swapping two elements of list function
{
  int temp = ((struct list*)first)->val;
  ((struct list*)first)->val = ((struct list*)second)->val;
  ((struct list*)second)->val = temp;
}

void *list_perv(void *in) // last element of list
{
  return ((struct list*)in)->prev;
}


void sort(void* struc, void *begin(void*), void *end(void*), void *next(void*), int cmp(void*,void*),  void swap(void*, void*), void *perve(void*)) // iteration function
{
  void *i = begin(struc);
  void *last = end(struc);
  i = next(i);
  for (; ; i = next(i)) {
  for (void *j = i;cmp(j, perve(j)) < 0; j = perve(j))
  {
  swap(j, perve(j));
  if (j == next(begin(struc))) break;
  }
  if (i == last) break;
  }
}

struct list* Createlist() // creating list function
{
  int size;
  printf("\n\nEnter the size of list: ");
  scanf ("%d", &size); 
  int a[size];
  struct list* lst= NULL; 
 // struct list* p=lst;  
  printf("Enter %d integer numbers: ", size);
  for (int i = 0; i<size ;i++)
  {
    scanf("%d",&a[i]);
    add(&lst, a[i]);         
  }
  if (size == 1)
  {
    printf("Sorted list: \n");
    printf("%d ", lst->val);
    printf("\nSorted list IN REVERSE ORDER: \n");
    printf("%d ", lst->val);
    return NULL;
  }
  return lst;
}

void arrprint(int* arr) // print array function
{
  printf("Sorted array: ");
  for (int i = 1; i < arr[0]+1; i++) printf ("%d ",  arr[i]);
}

int* Createarray() // creating array function
{
  int* p;
  int **pp;
  int size;
  printf("\nEnter the size of array: ");
    scanf ("%d", &size);
  p=(int*)malloc((size+1)*sizeof(int));
  printf("Enter %d integer numbers: ", size);
  p[0]=size;
  for(int i=1;i<size+1; i++)
   scanf("%d", &p[i]);
   if (size == 1)
  {
    printf("Sorted array: \n"); 
    printf("%d", p[1]);
    return NULL;
  }
  pp=(int**)malloc((size+1)*sizeof(int*));//создаем   динамический масссив указателей  
   //for(int i=1;i<size+1; i++)//заполнение массива указателей
   //pp[i]=&p[i];

 // }
  return p;
}


struct tree* AddTreeLeaf(int v) { // function to create a new leaf of the tree  
  struct tree *tmp = (struct tree*)malloc(sizeof(struct tree));
  tmp->left = tmp->right = tmp->center = NULL;
  tmp->val[0] = v; tmp->val[1] = 0;
  return tmp;
}

struct tree* InsertValue(struct tree **pp, int v) { // function of inserting an element into a tree while maintaining the tree order 
  if ((*pp) == NULL) { // creating a new leaf of the tree
    (*pp) = AddTreeLeaf(v);
    return(*pp);
  }
  if ((v == (*pp)->val[0]) || (v == (*pp)->val[1])) {
    printf("\n --- Do not enter the number that already here --- \n");
    return (*pp);
  }
  if ((v > (*pp)->val[0]) && ((*pp)->val[0]) && ((*pp)->val[1] == 0)) {
    (*pp)->val[1] = v; 
    return (*pp); // the second number is added to the leaf of the tree  
  } 
  /* recursive search for the insertion point of an element */
  if ((*pp)->val[0] > v)
    (*pp)->left = InsertValue(&(*pp)->left, v);
  else {
    if (((*pp)->val[0] < v) && ((*pp)->val[1] > v))
      (*pp)->center = InsertValue(&(*pp)->center, v);
    else (*pp)->right = InsertValue(&(*pp)->right, v);
  }
  return (*pp);
}

int ScanTree(struct tree *root, int level, int n) { // tree traversal function from top to bottom and from left to right; the result is an ordered numeric sequence 
  if (root == NULL) return n;

  if (root->val[0] == 12) {
    printf("\n");
    for (int i = 4; i > 0; i--) printf("   ");
    printf(" %d", root->val[0]);
    if (root->val[1] == 0) printf(" NULL\n");
    else printf(" %d\n", root->val[1]);
  }

  if ((root->left) != NULL) {
    n++;
    printf("   ");  
    printf(" %d", (root->left)->val[0]);
    if ((root->left)->val[1] == 0) printf(" NULL");
    else printf(" %d", (root->left)->val[1]);
  }

  if ((root->center) != NULL) {
    n++;
    printf("   ");
    printf("%d", (root->center)->val[0]);
    if ((root->center)->val[1] == 0) printf(" NULL");
    else printf(" %d", (root->center)->val[1]);
  }

  if ((root->right) != NULL) {
  n++;
  printf("   ");
  printf("%d", (root->right)->val[0]);
  if ((root->right)->val[1] == 0) printf(" NULL");
  else printf(" %d", (root->right)->val[1]);
  }

  if (n == level) {
    printf("\n");
    level *= 3;
    n = 0;
  }

  if ((root->left) != NULL) n = ScanTree(root->left, level, n);
  if ((root->center) != NULL) n = ScanTree(root->center, level, n);
  if ((root->right) != NULL) n = ScanTree(root->right, level, n);
  return n;
}

int Choice() { // selection function: add a new number or exit the program 
  int ans;
  printf("\n\nDo you want to add new number?\n[1] Yes \n[0] No \n-> Enter the number of your choice = ");
  scanf("%d", &ans);
  return ans;
}

struct tree* StartTree(struct tree *root) { // creating the start tree function
  root->val[0] = 12; root->val[1] = 24;
  root->left = root->right = root->center = NULL;
  InsertValue(&root, 6);
  InsertValue(&root, 13);
  InsertValue(&root, 17);
  InsertValue(&root, 25);
  InsertValue(&root, 27);
  printf("\n\n          START TREE"); ScanTree(root, 3, 0); // displaying the start tree
  return root;
}

void AddNum(struct tree *root) { // adding new elements to the tree function
  if (Choice()) {
    int v;
    printf("\n-> Enter integer number for insert in tree (not 0) = ");
    scanf("%d", &v); 
    InsertValue(&root, v);
    printf("\n\n            NEW TREE"); ScanTree(root, 3, 0); // output to the console of the tree with the new element
    AddNum(root);
  } 
}

void ClearScreen() { // console purge function 
  #if(windows)
  system("cls");
  #else
  system("clear");
  #endif
}

void Menu()
{
  printf("\n[1] Sort array\n");
  printf("[2] Sort list\n");
  printf("[3] Add new numbers to the tree\n");
  printf("[0] Exit\n");
}

int main() {
  int m; ClearScreen();
  Menu();
  while(1) {
    printf("\n\nWhat do you want to do? Enter the int number from 0 to 3\n");
    scanf("%d", &m);
    switch(m) {
      case 0: return 0; // Exit the program
      case 1: {
        int *arr = Createarray();  
        if (arr != NULL) {
        sort((void*)arr, arr_first, arr_last, arr_next, arr_cmp, arr_swap, arr_perv);
        arrprint(arr); }
        free(arr);  
        }
      break;
      case 2: {
        struct list* lst = Createlist();
        if (lst!=NULL) {
        sort((void*)lst, list_first, list_last, list_next, list_cmp, list_swap,list_perv);
        listprint(lst);
        }
        free(lst);}
      break;
      case 3: {
        struct tree *root = (struct tree*)malloc(sizeof(struct tree));
        StartTree(root); // creating the start tree
        AddNum(root); // adding new elements to the tree
        //sort((void*)root, node_first, node_last, node_next, node_cmp, node_swap, node_perv);
        free(root);}
      break;
      default:
        printf("Wrong number. Enter the number of menu");
      break;
    }
  }
}