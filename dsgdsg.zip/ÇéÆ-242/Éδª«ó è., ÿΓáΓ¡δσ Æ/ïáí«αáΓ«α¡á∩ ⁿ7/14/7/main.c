#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct linked_list {
    struct linked_list *prev, *next;
    int data;
    char string[100];
} linked_list;

void file_read(int *buf_int, char **buf_str, int n) {
    FILE *fp;
    if ((fp = fopen("read.txt", "r")) == NULL) {
        printf("Can't open file 'read.txt'\n");
        exit(-1);
    }
    for (int i = 0; i < n; i++) {
        fscanf(fp, "%s", buf_str[i]);
        fscanf(fp, "%d", &buf_int[i]);
    }
    fclose(fp);
}


void push_list(linked_list **head, int value, char *string) {
    linked_list *p = (linked_list *) malloc(sizeof(linked_list));
    (*head)->prev = p;
    p->prev = NULL;
    p->next = *head;
    p->data = value;
    strcpy(p->string, string);
    *head = p;
}

void init_list(linked_list **head, int value, char *string) {
    linked_list *p = (linked_list *) malloc(sizeof(linked_list));
    p->prev = NULL;
    p->next = NULL;
    p->data = value;
    strcpy(p->string, string);
    *head = p;
}

void print_list(linked_list **head) {
    for (linked_list *p = *head; p != NULL; p = p->next)
        printf("%s %d \n", p->string, p->data);
}


void swap(void *q, void *p) {

    linked_list *tmp = (linked_list *) malloc(sizeof(linked_list));
    linked_list *qs;
    linked_list *ps;
    qs = q;
    ps = p;
    if (qs->prev != NULL)
        qs->prev->next = tmp;
    qs->next->prev = tmp;
    tmp->prev = qs->prev;
    tmp->next = qs->next;

    ps->prev->next = qs;
    if (ps->next != NULL)
        ps->next->prev = qs;
    qs->next = ps->next;
    qs->prev = ps->prev;

    if (tmp->prev != NULL)
        tmp->prev->next = ps;
    if (tmp->next != NULL)
        tmp->next->prev = ps;
    ps->prev = tmp->prev;
    ps->next = tmp->next;
}

int cmp_int(linked_list *first, linked_list *second) {
    if (second->data < first->data) return 1;
    else return 0;
}

int cmp_str(linked_list *first, linked_list *second) {
    if (strcmp(second->string, first->string) < 0)
        return 1;
    return 0;
}

void buble_sort_list(void **head, int (*compare)(), int n) {
    for (int i = 0; i < n; i++) {
        for (linked_list *p = *head; p->next != NULL; p = p->next) {
            if (compare(p, p->next)) {
                if (p == *head)
                    *head = p->next;
                swap(p, p->next);
                p = p->prev;
            }
        }
    }
}


void free_buf(int *buf_int, char **buf_str, int n) {
    free(buf_int);
    for (int i = 0; i < n; i++) {
        free(buf_str[i]);
    }
    free(buf_str);
}

int main() {
    int n = 10, m = 100;
    int *buf_int = (int *) malloc(n * sizeof(int));
    char **buf_str = (char **) malloc(n * sizeof(char *));
    for (int i = 0; i < n; i++) {
        buf_str[i] = (char *) malloc(m * sizeof(char));
    }

    file_read(buf_int, buf_str, 10);

    linked_list *list;

    // заполнение списка
    for (int i = 0; i < n; i++) {
        if (i == 0)
            init_list(&list, buf_int[i], buf_str[i]);
        else
            push_list(&list, buf_int[i], buf_str[i]);
    }

    free_buf(buf_int, buf_str, n);

    printf("\nList:\n");
    print_list(&list);
    printf("\nsort by value:\n");
    buble_sort_list((void *) &list, cmp_int, n);
    print_list(&list);
    printf("\nsort by string:\n");
    buble_sort_list((void *) &list, cmp_str, n);
    print_list(&list);

}

