#include "stdafx.h"
#include <stdio.h>
#include <malloc.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#define size 15
#define word_size 5

//typedef struct List List;

struct List {

	int value;
	char* str;
	struct List* prev;
	struct List* next;

};

//All for list
void initializeList(List** head, int val, char* str_tmp) {

	List* tmp = (List*)malloc(sizeof(List));
	int i = 0;
	tmp->str = (char*)malloc((word_size + 1) * sizeof(char));
	while (str_tmp[i - 1] != '\0') {
		tmp->str[i] = str_tmp[i];
		i++;
	}
	tmp->str[i + 1] = 0;
	tmp->value = val;
	tmp->next = NULL;
	tmp->prev = NULL;
	*head = tmp;

}

void pushList(List** head, int val, char* str_tmp) {

	List* tmp = (List*)malloc(sizeof(List));
	int i = 0;
	tmp->str = (char*)malloc((word_size + 1) * sizeof(char));
	while (str_tmp[i - 1] != '\0') {
		tmp->str[i] = str_tmp[i];
		i++;
	}
	tmp->str[++i] = '\0';
	tmp->value = val;
	tmp->next = *head;
	tmp->prev = (*head)->prev;
	(*head)->prev = tmp;
	*head = tmp;

}

void fillInTheList(List** head) {

	char* str_tmp = (char*)malloc((word_size + 1) * sizeof(char));
	srand(time(NULL));
	for (int i = 0; i < word_size; i++) str_tmp[i] = rand() % 26 + 97;
	str_tmp[word_size] = '\0';
	initializeList(head, rand() % 100, str_tmp);
	for (int i = 0; i < size - 1; i++) {
		for (int j = 0; j < word_size; j++) str_tmp[j] = rand() % 26 + 97;
		str_tmp[word_size] = '\0';
		pushList(head, rand() % 100, str_tmp);
	}

}
void swap(List* q, List* p) {

	List* tmp = (List*)malloc(sizeof(List));
	List* qs;
	List* ps;
	qs = q;
	ps = p;
	if (qs->prev != NULL)
		qs->prev->next = tmp;
	qs->next->prev = tmp;
	tmp->prev = qs->prev;
	tmp->next = qs->next;

	ps->prev->next = qs;
	if (ps->next != NULL)
		ps->next->prev = qs;
	qs->next = ps->next;
	qs->prev = ps->prev;

	if (tmp->prev != NULL)
		tmp->prev->next = ps;
	if (tmp->next != NULL)
		tmp->next->prev = ps;
	ps->prev = tmp->prev;
	ps->next = tmp->next;
}

//Compares

int compareListInt(List* first, List* second) {

	if (second->value < first->value) return 1;
	else return 0;
}

int compareListStr(List* first, List* second) {

	for (int i = 0; i < word_size; i++) {
		if (second->str[i] < first->str[i]) return 1;
		else if (second->str[i] == first->str[i]) continue;
		return 0;
	}
}

int compareArrIntDesc(void* a, void* b) {
	return *((int*)a) < *((int*)b);
}

int compareArrIntAsc(void* a, void* b) {
	return *((int*)a) > * ((int*)b);
}

int compareArrCharAsc(void* a, void* b) {
	return *((char*)a) < *((char*)b);
}

int compareArrCharDesc(void* a, void* b) {
	return *((char*)a) > * ((char*)b);
}

//Iterators

void bubleSort(List** head, int(*compare)(List* first, List* second), void(*swap)(List* first, List* second)) {

	for (int i = 0; i < size; i++) {
		for (List* p = *head; p->next != NULL; p = p->next)
			if (compare(p, p->next)) {
				if (p == *head)
					*head = p->next;
				swap(p, p->next);
				p = p->prev;
			}
	}
}

void insertionSort(void* arr, unsigned num, size_t size2, int(*compare)(void* a, void* b)) {
	unsigned i, j;
	char* ptr = (char*)arr;
	char* tmp = (char*)malloc(size2);
	for (i = 1; i < num; i++) {
		if (compare(ptr + i * size2, ptr + (i - 1) * size2)) {
			j = i;
			while (compare(ptr + j * size2, ptr + (j - 1) * size2) && j > 0) {
				memcpy(tmp, ptr + j * size2, size2);
				memcpy(ptr + j * size2, ptr + (j - 1) * size2, size2);
				memcpy(ptr + (j - 1) * size2, tmp, size2);
				j--;
			}
		}
	}
}

//Calling functions
void list() {

	List* head = NULL;
	fillInTheList(&head);
	printf("Unsorted:\n");
	for (List* p = head; p != NULL; p = p->next)
		printf("%d ", p->value);
	printf("\n");
	for (List* p = head; p != NULL; p = p->next) {
		printf(p->str);
		printf(" ");
	}
	bubleSort((List**)&head, compareListInt, swap);
	printf("\n");
	printf("\nSorted by int:\n");
	for (List* p = head; p != NULL; p = p->next) {
		printf("%d ", p->value);
	}
	printf("\n");
	printf("\nSorted by string:\n");
	bubleSort((List**)&head, compareListStr, swap);
	for (List* p = head; p != NULL; p = p->next) {
		printf(p->str);
		printf(" ");
	}
	printf("\n\n");
}

void arr() {
	int a1 = 5, a2 = 6, a3 = 3, a4 = 2;
	int* a[] = { &a1, &a2, &a3, &a4, NULL };
	char b1 = 'c', b2 = 'd', b3 = 'y', b4 = 'q';
	char* b[] = { &b1, &b2, &b3, &b4, NULL };
	int i;

	printf("Unsorted:\n");
	for (i = 0; i < 4; i++)
		printf("%d ", *a[i]);
	printf("\n");
	for (i = 0; i < 4; i++)
		printf("%c ", *b[i]);
	printf("\n");

	printf("\nSorted by int:\n");
	insertionSort(a, 4, sizeof(int), compareArrIntAsc);
	for (i = 0; i < 4; i++) {
		printf("%d ", *a[i]);
	}
	printf("\n");
	insertionSort(a, 4, sizeof(int), compareArrIntDesc);
	for (i = 0; i < 4; i++) {
		printf("%d ", *a[i]);
	}
	printf("\n");

	printf("\nSorted by char:\n");
	insertionSort(b, 4, sizeof(char*), compareArrCharAsc);
	for (i = 0; i < 4; i++) {
		printf("%c ", *b[i]);
	}
	printf("\n");
	insertionSort(b, 4, sizeof(char*), compareArrCharDesc);
	for (i = 0; i < 4; i++) {
		printf("%c ", *b[i]);
	}
	printf("\n\n");
}
//Main
void main() {
	int Ex = 0;
	do {
		printf("Which Iterator?\n");
		printf("1. Iterator of sorting for an array\n");
		printf("2. Iterator of sorting for an List\n");
		printf("3. Exite\n");
		printf("Your choice: \n");
		int input;
		scanf("%d", &input);
		switch (input) {

		case 1:
			arr();
			continue;
		case 2:
			list();
			continue;
		case 3:
			Ex = 1;
			printf("Goodbye :(\n");
			break;
		default:
			printf("Invalid input.\n");
		}
	} while (Ex != 1);
}
