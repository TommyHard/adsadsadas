#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <malloc.h>

typedef struct list
{
	int val;
	struct list* next;
}list;

list* getLast(list* pHead) // seek last element on list
{
	list* l = pHead;
	while (l->next != pHead) {
		l = l->next;
	}
	return l;
}

void pushBack(list* pHead, int val)//add new element on back of list
{
	list* last = getLast(pHead);
	list* support_list = (list*)malloc(sizeof(list));
	support_list->val = val;
	support_list->next = pHead;
	last->next = support_list;
}

void autoAddInList(list* pHead, int n)//generate element from list
{
	pHead->val = rand() % 10;
	pHead->next = pHead;
	for (int i = 0; i < n - 1; i++)
		pushBack(pHead, rand() % 10);
}

void printList(list* pHead)
{
	list* l = pHead;
	do
	{
		printf("%d ", l->val);
		l = l->next;
	} while (l != pHead);

	printf("\n");
}

void intersectionTwoList(list* first_list, list* second_list, int len_first_list, int len_second_list)
{
	int* intersection = (int*)malloc(sizeof(int));
	int len = 1;
	int k;
	for (int i = 0; i < len_first_list; i++)//As first and second list are cycle, then there list don't check at the end
	{
		for (int j = 0; j < len_second_list; j++)
		{
			if (first_list->val == second_list->val)
			{
				for (k = 0; k < len; k++)//for eliminate repetition in array
					if (intersection[k] == first_list->val)
						break;

				if (k == len)
				{
					intersection[len - 1] = first_list->val;
					len++;
					intersection = (int*)realloc(intersection, len * sizeof(int));
				}

				break;
			}
			second_list = second_list->next;
		}
		first_list = first_list->next;
	}

	for (int i = 0; i < len - 1; i++)
		printf("%d ", intersection[i]);
	printf("\n");
}

int main()
{
	int len_first_list = 10, len_second_list = 15;
	list* first_list = (list*)malloc(sizeof(list));//create first list
	first_list->next = NULL;
	list* second_list = (list*)malloc(sizeof(list));//create second list
	second_list->next = NULL;
	srand(time(NULL));

	autoAddInList(first_list, len_first_list);//initilization first list
	autoAddInList(second_list, len_second_list);//initilization second list

	printf("First list:\n");
	printList(first_list, len_first_list);

	printf("Second list:\n");
	printList(second_list, len_second_list);

	printf("Result:\n");
	intersectionTwoList(first_list, second_list, len_first_list, len_second_list);

	return 0;
}
