#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>

char* LongWord(char* a, int* j) //seek long word
{
	int count = 0, maxcount = -1, pos = 0;

	for (int i = 0; i < *j; i++)
	{
		count++;
		if (a[i] == ' ' || i+1 == *j)//if ' ' or i+1=j => new word detected
		{
			if (a[i] == ' ')//bcs space in count 
			{
				count--;
			}
			if (count > maxcount)
			{
				maxcount = count;
				pos = i - count;//word position
				if (i + 1 == *j)
					pos++;
			}
			
			count = 0;
		}
	}
	
	return &a[pos];
}

void PrintDelete(char* a, int* j, int* wc)//print and delete word
{
	char* word;//this word
	word = LongWord(a, j);//seek word in string
	
	for (int i = 0; word[i] != '\n' && word[i] != ' '; i++)//print word
	{
		printf("%c",word[i]);
		word[i] = ' ';
	}
	
	for (int i = 0; i < (*j) - 1; i++)//delete word
	{
		if (a[i] == ' ' && a[i + 1] == ' ')
		{
			for (int q = i; q < (*j); q++)
				a[q] = a[q + 1];
			(*j)--;
		}
	}

	printf("\n");
	(*wc)++;//count of delete word
}

int main()
{
	int j = 1; //start lenght 
	
	
	int countSpace = 0;//count space
	char* a = (char*)malloc(j * sizeof(char)); //string
	int word_counter = 0;//count of delete word

	printf("Print your string: \n");

	do
	{
		a[j - 1] = getchar();
		j++;
		if (a[j - 2] == ' ')
			countSpace++;
		a = (char*)realloc(a, j * sizeof(char));
	} while (a[j - 2] != '\n'); //print string in a
	
	j -= 2;//new lenght, a[j] == '\n'

	while (word_counter != (countSpace+1))//while count delete word not equivalent count space 
	{
		PrintDelete(a, &j,&word_counter);//print word and delete
	}


	return 0;
}