#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>

struct student //Student!
{
	char name[20];//name
	int countMarks;//count mark
	int* Marks;//this mark
	double average;//average mark
};

struct student setStudent( char name[20], int cM, int* Ma)
{
	struct student s;
	int summ = 0;
	for (int i = 0; i < 20; i++)
		s.name[i] = name[i];
	s.countMarks = cM;
	s.Marks = (int*)malloc(cM * sizeof(int));
	for (int i = 0; i < cM; i++)
	{
		s.Marks[i] = Ma[i];
		summ += Ma[i];
	}
	
	s.average = (double)summ / (double)cM;

	return s;
}

struct student addStudent()//Write student from console
{
	int i = 0;
	int summ = 0;
	struct student s;

	printf("Write surname of student: ");
	fseek(stdin, 0, SEEK_END);
	do
	{
		scanf("%c", &s.name[i]);
		i++;
	} while (i < 20 && s.name[i - 1] != '\n');
	for (; i < 20; i++)
		s.name[i] = ' ';


	printf("Write count mark(s) of student: ");
	scanf("%d",&s.countMarks);

	s.Marks = (int*)malloc(s.countMarks*sizeof(int));
	for (i = 0; i < s.countMarks; i++)
	{
		scanf("%d", &s.Marks[i]);
		summ += s.Marks[i];
	}

	s.average = (double)summ / (double)s.countMarks;
	
	printf("Your student save!\n");

	return s;
}

struct student autoaddStudent()//Auto write student
{
	struct student s;
	char name[20];
	int cM;
	int* Ma;
	int x = (int)(rand() % 20);
	x++;


	int i;
	for (i = 0; i < 20; i++)
	{
		name[i] = (char)((rand() % 26) + 65);
	}
	

	cM = rand() % 11 + 1;
	printf("Count mark(s): %d\n\n",cM);

	Ma = (int*)malloc(cM * sizeof(int));
	for (i = 0; i < cM; i++)
	{
		Ma[i] = rand() % 4 + 2;
	}
	
	s = setStudent(name, cM, Ma);

	return s;
}

void exportToFile(struct student s)//Add this student in file
{
	char n[] = "D:\\StudentText.txt";;
	FILE *f = fopen(n, "a");

	fprintf(f, "N: ");
	for (int i = 0; i < 20; i++)
		fprintf(f,"%c",s.name[i]);
	fprintf(f,"\n");

	fprintf(f,"C: %d\n",s.countMarks);

	fprintf(f, "M: ");
	for (int i = 0; i < s.countMarks; i++)
		fprintf(f,"%d ",s.Marks[i]); 
	fprintf(f, "\nA: %.2lf",s.average);

	fprintf(f, "\n---\n");

	fclose(f);
}

struct student* importFromFile(int* len)//Load all student from file
{
	char n[] = "D:\\StudentText.txt";
	int q = 0; 
	char name[20];
	for (int i = 0; i < 20; i++)
		name[i] = ' ';
	char r;

	int c;
	int* m = (int*)malloc(0*sizeof(int));
	FILE* f = fopen(n, "r");

	*len = 0;
	struct student* s = (struct student*)malloc(((*len) + 1) * sizeof(struct student));

	while (feof(f) == 0)
	{		
		r = fgetc(f);
		if (r == 'N')
		{
			r = fgetc(f);
			r = fgetc(f);
			int i1 = 0;
			while (r != '\n' && i1 < 20)
			{
				r = fgetc(f);
				name[i1] = r;
				i1++;
			}
		}
		else if (r == 'C')
		{
			r = fgetc(f);
			r = fgetc(f);
			r = fgetc(f);

			c = (int)r - 48;

			r = fgetc(f);

			if (r >= '0' && r <= '9')
			{
				c *= 10;
				c += ((int)r - 48);
			}
		}
		else if (r == 'M')
		{
			r = fgetc(f);
			r = fgetc(f);
			int i1 = 0;
			m = (int*)malloc(c * sizeof(int));
			while(r != '\n' && i1 < c)
			{
				r = fgetc(f);
				if (r != ' ')
				{
					m[i1] = (int)r - 48;
					i1++;
				}
			}
		}
		else if (r == '-')
		{
			r = fgetc(f);
			r = fgetc(f);

			s[(*len)] = setStudent(name, c, m);
			(*len)++;
			s = (struct student*)realloc(s,((*len) + 1) * sizeof(struct student));
		}
	}
		fclose(f);

		return &s[0];
}

void printListOfStudents(struct student* arr, int count)//print array of student in console
{
	if (count == 0)
	{
		printf("Sorry, list is void\n");
	}
	else
	{
		for (int i = 0; i < count; i++)
		{
			printf("%d:\n", i + 1);
			printf("Student: ");
			for (int j = 0; j < 20; j++)
			{
				printf("%c",arr[i].name[j]);
			}
			printf("\nCount mark(s): %d\n", arr[i].countMarks);
			printf("Mark(s): ");
			for (int j = 0; j < arr[i].countMarks; j++)
			{
				printf("%d ", arr[i].Marks[j]);
			}
			printf("\nAverage score: %.2lf\n**********\n",arr[i].average);
		}
	}
}

struct student* sortCategory(struct student* arr, int len, int set)//Sort array of student by category
{
	struct student s;
	switch (set)
	{
		//for name
	case 1: 
		for(int i = 0; i < len-1; i++)
			for (int j = i + 1; j < len; j++)
			{
				if (arr[i].name[0] > arr[j].name[0])
				{
					s = arr[i];
					arr[i] = arr[j];
					arr[j] = s;
				}
			}
		break;
		//for count mark
	case 2:
		for(int i = 0; i < len-1; i++)
			for (int j = i + 1; j < len; j++)
			{
				if (arr[i].countMarks > arr[j].countMarks)
				{
					s = arr[i];
					arr[i] = arr[j];
					arr[j] = s;
				}
			}
		break;
		//for average mark
	case 3:
		for(int i = 0; i < len-1; i++)
			for(int j = i+1; j < len;j++)
				if (arr[i].average > arr[j].average)
				{
					s = arr[i];
					arr[i] = arr[j];
					arr[j] = s;
				}
		break;
	default:
		printf("You don't sort\n");
		break;
	}

	return arr;
}

void removeStudent(struct student* arr, int* len, int set)//Delete student from array
{
	set--;
	for (int i = set; i < (*len)-1; i++)
		arr[i] = arr[i + 1];
	(*len)--;
}

struct student changeStudent(struct student s, int set)//choice category of student
{
	struct student sNew;
	char newname[20];
	int i = 0;
	int* nM;//new Mark
	int newCount;//new count mark

	switch (set)
	{
		//for name
	case 1: 
		printf("Write new surname of student:\n");
		fseek(stdin, 0, SEEK_END);
		i = 0;
		do
		{
			newname[i] = getchar();
			i++;
		} while (i < 20 && newname[i-1] != '\n');
		for (; i < 20; i++)
			newname[i] = ' ';

		sNew = setStudent(newname, s.countMarks, s.Marks);
		break;
		//for count Mark
	case 2:
		printf("Write new count mark:\n");
		
		scanf("%d", &newCount);

		if (newCount > s.countMarks)
		{
			printf("Oh! New count is begger then old count. You need write new mark:\n");
			nM = (int*)malloc(newCount * sizeof(int));
			nM = s.Marks;
			for (int j = s.countMarks; j < newCount; j++)
				scanf("%d", &nM[j]);
			sNew = setStudent(s.name, newCount, nM);
		}
		else
			sNew = setStudent(s.name, newCount, s.Marks);
		break;
		//for mark
	case 3:
		printf("Write new mark:\n");
		nM = (int*)malloc(s.countMarks*sizeof(int));
		for (int j = 0; j < s.countMarks; j++)
			scanf("%d", &nM[j]);
		sNew = setStudent(s.name, s.countMarks, nM);
		break;
	default:
		printf("Error: not found number.\n");
		break;
	}
	return sNew;
}

void allAverSumm(struct student* arr, int len, int set)//All average of list or all sum count mark
{
	int allSum = 0, allCM = 0;
	double allAver = 0.0;
	switch (set)
	{
		//for average
	case 1:
		for (int i = 0; i < len; i++)
		{
			for (int j = 0; j < arr[i].countMarks; j++)
				allSum += arr[i].Marks[j];
			allCM += arr[i].countMarks;
		}
		allAver = (double)allSum / (double)allCM;
		printf("All average: %.4lf\n", allAver);
		break;
		//for summ count mark
	case 2:
		allSum = 0;
		for (int i = 0; i < len; i++)
			allSum += arr[i].countMarks;
		printf("Summ count mark: %d\n",allSum);
		break;
	default:
		printf("Error. Incorrect number. Try again.\n");
		break;
	}

}

struct student seekParam(struct student* arr, int len, int set)// seek +- equalent parametr's in array
{
	struct student s;
	int i, countEQ[20], mc = -1,cc,ci;
	char nname[20];

	int ncount, minc = 100000;
	double naver, maver = 100000.0;

	switch (set)
	{
		//for name
	case 1:
		printf("Write surname:\n");
		fseek(stdin, 0, SEEK_END);
		i = 0;
		do
		{
			nname[i] = getchar();
			i++;
		} while (i < 20 && nname[i - 1] != '\n');
		for (i = i - 1; i < 20; i++)
			nname[i] = ' ';
		for (int j = 0; j < len; j++)
		{
			int u;
			for (u = 0; u < 20 && arr[j].name[u] == nname[u]; u++);
			if (u == 20)
			{
				s = arr[j];
				break;
			}
			else
			{
				for (int j1 = 0; j1 < 20; j1++)
					countEQ[j1] = 0;

				for (u = 0; u < 20; u++)
					if (arr[j].name[u] == nname[u])
						countEQ[u] = 1;

				
				cc = 0;
				
				for (int u = 0; u < 20; u++)
				{
					if (countEQ[u] == 0)
					{
						if (cc > mc)
						{
							mc = cc;
							ci = j;
						}
						cc = 0;
					}
					else cc++;
				}

				s = arr[ci];
			}
				
			
			
		}
		break;
		//for count
	case 2:
		printf("Write your count: \n");
		scanf("%d", &ncount);

		for(int j = 0; j < len; j++)
			if (abs(arr[j].countMarks - ncount) < minc)
			{
				minc = abs(arr[j].countMarks - ncount);
				ci = j;
			}
		s = arr[ci];
		break;
		//for average
	case 3:
		printf("Write your average: \n");
		scanf("%lf",&naver);

		for(int j = 0; j < len;j++)
			if (fabs(arr[j].average - naver) < maver)
			{
				maver = fabs(arr[j].average - naver);
				ci = j;
			}
		s = arr[ci];
		break;
	default:
		printf("Error. Incorrect number. Try again.\n");
		break;
	}

	return s;
}


int main()
{	
	int n, start_end = 1, set, st, set_point;
	int* lenF = &n;
	srand(time(NULL));
	struct student* arr = (struct student*)malloc(1 * sizeof(struct student));
	struct student s;

	while (start_end)
	{
		system("cls");// clear console
		printf("Choose point:\n0.Auto write student in list\n1. Write table with keybord.\n2. Load from file.\n3. Save in file.\n4. Look table.\n5. Seek in table.\n6. Delete student.\n7. Change your student.\n8. All summ.\n9. Exit.\nYour choice: ");
		//Every point - case
		fseek(stdin, 0, SEEK_END);//clear char for new char
		scanf("%d",&set_point);

		switch (set_point)
		{
		case 1:
			system("cls");
			printf("Write count student(Maxium 20): ");
			scanf("%d",&n);
			arr = (struct student*)realloc(arr, n * sizeof(struct student));
			for (int i = 0; i < n; i++)
				arr[i] = addStudent();
			printf("\n**********\n");
			break;
		case 2:
			system("cls");
			arr = importFromFile(lenF);
			printf("Load!\n**********\n");
			break;
		case 3:
			system("cls");
			if (n == 0)
			{
				printf("In table zero stuent!\n**********\n");
			}
			else
			{
				for (int i = 0; i < n; i++)
				{
					exportToFile(arr[i]);
				}
				printf("Save!\n**********\n");
			}
			break;
		case 4:
			system("cls");
			printListOfStudents(arr, n);
			break;
		case 5:
			system("cls");
			if (n == 0)
			{
				printf("List is void!\n**********\n");
			}
			else 
			{
				printf("1. By name.\n2. By count mark\n3. By average mark.\nYour choice: ");
				scanf("%d", &set);
				system("cls");
				s = seekParam(arr, n, set);
				printf("Surname: ");
				for (int i = 0; i < 20; i++)
					printf("%c", s.name[i]);
				printf("\nCount mark: %d\n",s.countMarks);
				printf("Mark: ");
				for (int i = 0; i < s.countMarks; i++)
					printf("%d ", s.Marks[i]);
				printf("\nAverage mark: %.2lf",s.average);
				printf("\n**********\n");
			}
			break;
		case 6:
			system("cls");
			if (n == 0)
			{
				printf("List is void!\n**********\n");
			}
			else
			{	
				printf("Write number student in list: ");
				scanf("%d", &set);
				if (set < 1 || set > n)
				{
					printf("This point is not exist\n**********\n");
				}
				else
				{
					removeStudent(arr, lenF, set);
					printf("This student is delete!\n**********\n");
				}
			}
			break;
		case 7:
			system("cls");
			if (n == 0)
			{
				printf("List is void!\n**********\n");
			}
			else
			{
				printf("Write point student: ");
				scanf("%d",&st);
				if (st < 1 || st > n)
				{
					printf("This point is not exist!\n**********\n");
				}
				else
				{
					system("cls");
					printf("What you want choice:\n1. Name.\n2.Count mark.\n3. Mark.\nYour choice: ");
					scanf("%d", &set);
					arr[st] = changeStudent(arr[st], set);
					printf("\n**********\n");
				}
			}
			break;
		case 8:
			system("cls");
			if (n == 0)
			{
				printf("List is void!\n**********\n");
			}
			else
			{
				printf("What you need summ:\n1. Average mark.\n2. All summ of count mark.\nYour choice: ");
				scanf("%d",&set);
				allAverSumm(arr, n, set);
				printf("\n**********\n");
			}
			break;
		case 9://exit
			start_end = 0;
			break;
		case 0://auto write student for lazy plp
			system("cls");
			point:
			printf("How your student?(Maxium 20)\n");
			scanf("%d", &n);
			if (n <= 20 && n >= 1)
			{
				for (int i = 0; i < n; i++)
					arr[i] = autoaddStudent();
			}
			else
			{
				system("cls");
				printf("Please write number in range(1; 20)\n");
				goto point;
			}
			break;
		default:
			break;
		}
		printf("Press any key to continue.\n");
		fseek(stdin, 0, SEEK_END);
		scanf("%*");
	}
	

	return 0;
}