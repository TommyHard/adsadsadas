#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <time.h>
#include <conio.h>

char* autoString(int* len) //generate str
{
	*len = rand() % 11 + 2;
	char* str = (char*)malloc((*len) * sizeof(char));
	for (int i = 0; i < *len; i++)
	{
		if (rand() % 2)
		{
			str[i] = 'A';
		}
		else
			str[i] = 'B';
	}

	return str;
}

void printString(char* str, int len)//print string
{
	for (int i = 0; i < len; i++)
		printf("%c", str[i]);
	printf("\n");
}

int min(int a, int b, int c)
{
	if (a < b && a < c)
		return a;
	else if (b < a && b < c)
		return b;
	else
		return c;
}

int equaleChar(char c1, char c2)
{
	if (c1 == c2)
		return 0;
	else
		return 2;
}

int distanceLevenshtein(int i, int j, char* str1, char* str2)
{
	if (i == 0 && j == 0)
		return 0;
	else if (i > 0 && j == 0)
		return i;
	else if (i == 0 && j > 0)
		return j;
	else if (i > 0 && j > 0)
		return min(distanceLevenshtein(i, j - 1, str1, str2) + 1, distanceLevenshtein(i-1 , j, str1, str2) + 1, distanceLevenshtein(i-1, j-1, str1, str2) + equaleChar(str1[i - 1], str2[j - 1]));
}

int main()
{
	char *a, *b;
	int len_1 = 0, len_2 = 0;
	int count = 0;
	srand(time(NULL));
	
	a = autoString(&len_1);//generate and print first string 
	printString(a, len_1);
	
	b = autoString(&len_2);//generate and print second string
	printString(b, len_2);

	count = distanceLevenshtein(len_1, len_2, a, b);
	printf("%d\n",count);

	return 0;
}
