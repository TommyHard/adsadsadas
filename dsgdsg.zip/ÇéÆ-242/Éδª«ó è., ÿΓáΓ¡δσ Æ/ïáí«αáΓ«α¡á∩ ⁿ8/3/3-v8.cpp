#define _CRT_SECURE_NO_WARNINGS
#include <malloc.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>


char** importFromFile(int size)
{
	FILE* f = fopen("D:\\Label3.txt", "r");//open file
	char** word = (char**)malloc(size * sizeof(char*));
	int fn;
	
	for(int i = 0; i < size;i++)
	{
		fn = -1;
		word[i] = (char*)malloc(0 * sizeof(char));
		do 
		{
			fn++;
			word[i] = (char*)realloc(word[i], (fn + 1) * sizeof(char));
			word[i][fn] = fgetc(f);
		} while (word[i][fn] != ' ' && word[i][fn] != '\n');

		word[i][fn] = NULL;//for task

	}
	
	fclose(f);
	return word;
}

void printArray(char** word, int size)
{
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; word[i][j] != NULL; j++)
			printf("%c", word[i][j]);
		printf("\n");
	}
}

int compare(char* word_1, char* word_2)//compare word, different char in priority
{
	int i = 0, i1 = 0, i2 = 0;
	while (word_1[i1] != NULL)
		i1++;
	while (word_2[i2] != NULL)
		i2++;
		
	while (word_1[i] != NULL && word_2[i] != NULL && word_2[i] == word_1[i])
		i++;

	if (word_1[i] != word_2[i])
	{
		if (word_1[i] > word_2[i])
			return 1;
		else
			return 2;
	}
	else
	{
		if (i1 > i2)
			return 1;
		else
			return 2;
	}
}

char* sortUnsortFirstLvl(char* word)//sord array by bubble
{
	int len;
	char c;
	for (len = 0; word[len] != NULL; len++);

	for(int i = 0; i < len-1;i++)
		for(int j = i+1;j<len;j++)
			if (word[i] > word[j])
			{
				c = word[i];
				word[i] = word[j];
				word[j] = c;
			}
	return word;
}

char** sortUnsortSecondLvl(char** word, int size)
{
	int newsize_first, newsize_second;
	if (size % 2 == 0)
	{
		newsize_first = size / 2;
		newsize_second = size / 2;
	}
	else
	{
		newsize_first = size / 2;
		newsize_second = (size / 2) + 1;
	}
	char** first_word = (char**)malloc(newsize_first * sizeof(char*));//split array of word on two arrays
	char** second_word = (char**)malloc(newsize_second * sizeof(char*));
	char** rw = (char**)malloc(size * sizeof(char*));// result array

	for (int i = 0; i < newsize_first; i++)
		first_word[i] = word[i];

	for (int i = newsize_first; i <= size; i++)
		second_word[i - newsize_first] = word[i];

	if (newsize_first > 1)//go to array with length == 1
		first_word = sortUnsortSecondLvl(first_word, newsize_first);
	if(newsize_second > 1)
		second_word = sortUnsortSecondLvl(second_word, newsize_second);

	int count1 = 0, count2 = 0, res;//newsize = count1 + count2 => this iteration "go" all two arrays, res - result of compare

	for (int i = 0; i < size; i++)
	{
		if (count1 < newsize_first && count2 < newsize_second)
			res = compare(first_word[count1], second_word[count2]);
		else
			res = 1;//if res 2, then all don't change

		switch (res)//switch for merge
		{
		case 1:
			if (count2 < newsize_second)
			{
				rw[i] = second_word[count2];
				count2++;
			}
			else
			{
				rw[i] = first_word[count1];
				count1++;
			}
			break;
		case 2:
			if (count1 < newsize_first)
			{
				rw[i] = first_word[count1];
				count1++;
			}
			else
			{
				rw[i] = second_word[count2];
				count2++;
			}
			break;
		default:
			break;
		}
	}

	return rw;
}

int main()
{
	int size = 9;// count word in file

	char** word;//this words

	word = importFromFile(size);//import from file

	printf("Start array: \n\n");
	printArray(word, size);

	for (int i = 0; i < size; i++)//sort char in this word
		word[i] = sortUnsortFirstLvl(word[i]);

	word = sortUnsortSecondLvl(word, size);//sort array of word by sort of merge

	printf("**********************************\nSorted array: \n\n");
	printArray(word, size);

	return 0;
}