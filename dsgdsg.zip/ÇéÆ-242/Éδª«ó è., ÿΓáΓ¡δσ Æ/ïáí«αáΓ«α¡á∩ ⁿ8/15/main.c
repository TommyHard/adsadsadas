#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 int count=0;
typedef struct sym // structure for writing
{
  unsigned char ch;
  float freq; 
  char code[255];
  struct sym *left;
  struct sym *right;
} sym;
 
union code
{
  unsigned char chhh; // variable containing the code to write to the compressed file
 
  struct byte {
    unsigned b1:1, b2:1, b3:1, b4:1, b5:1, b6:1, b7:1, b8:1;      
  } byte;
};
 
sym *makeTree(sym *psym[], int k) // recursive Huffman tree creation function
{
  sym *temp;
  temp = (sym*)malloc(sizeof(sym));
  if(k==1)
  return temp;;
  temp->freq = psym[k-1]->freq + psym[k-2]->freq;
  temp->code[0] = 0;
  temp->left = psym[k-1];
  temp->right = psym[k-2];
  if (k == 2) return temp;
  else // adding an element of the Huffman tree to the array at the desired place
  {
    for (int i = 0; i < k; i++)
    if (temp->freq > psym[i]->freq)
    {     
      for (int j = k - 1; j > i; j--)
        psym[j] = psym[j-1];                                  
        psym[i] = temp;
        break;
    }       
  }
  return makeTree(psym, k-1);
}
 
void makeCodes(sym *root) // Recursive encoding function
{
  if (root->left)
  {
    strcpy(root->left->code, root->code);
    strcat(root->left->code, "1");
    count++;
    makeCodes(root->left);
    }
  if (root->right)
  {
    strcpy(root->right->code,root->code);
    strcat(root->right->code,"0");

    makeCodes(root->right);
  }
  
}
 

int main ()
{
  FILE *fp, *fp2, *fp3; 
  fp = fopen("123.txt","rb"); // open a specific file
  fp2 = fopen("teemp.txt","wb"); // open the file to write the binary code
  fp3 = fopen("7777.txt","wb"); // open the file to write the compressed file
 
  int chh;  
  int k = 0; 
  int kk = 0; 
  int fsize2 = 0; 
  int ts; 
  int kolvo[256] = {0}; 
  sym simbols[256] = {0}; 
  sym *psym[256];
  float summir = 0; 
  int mes[8];
  char j = 0; 
    
  if (fp == NULL) //Handling file read errors
  {
    puts("FILE NOT OPEN");
    return 0;
  }
 
  sym *symbols = (sym*)malloc(k*sizeof(sym)); //creating a dynamic array of symbols structures
  sym **psum = (sym**)malloc(k*sizeof(sym*)); //creating a dynamic array of pointers to symbols
    
  while ((chh=fgetc(fp))!=EOF)// byte reading of the file and compiling an occurrence table
  {       
    for (int j = 0; j < 256; j++)
    {
      if (chh == simbols[j].ch)
      {
        kolvo[j]++;
        kk++;               
        break;
      }
      if (simbols[j].ch == 0)
      {
        simbols[j].ch = (unsigned char)chh;
        kolvo[j] = 1;
        k++; kk++;
        break;
      }           
    }       
  }
 
  for (int i = 0; i < k; i++)  // Calculating the frequency of occurrence
  simbols[i].freq = (float)kolvo[i]/kk;
    
  for (int i = 0; i < k; i++) // the addresses of the records into the array of pointers
  psym[i] = &simbols[i];
    
  sym tempp;
  for (int i = 1; i < k; i++) {//Sort descending 
    for (int j = 0; j < k - 1; j++)
      if (simbols[j].freq < simbols[j+1].freq)
      {
        tempp = simbols[j];
        simbols[j] = simbols[j+1];
        simbols[j+1] = tempp;
      }
  }

  for (int i = 0; i < k; i++)
  {
    summir += simbols[i].freq;    
    printf("Ch= %d\tFreq= %f\tPPP= %c\t\n", simbols[i].ch, simbols[i].freq, psym[i]->ch);
  }

  printf("\n Slova = %d\tSummir=%f\n", kk, summir);
    
  sym *root = makeTree(psym, k); 
    
  makeCodes(root); 
 
  rewind(fp); 

  while ((chh = fgetc(fp)) != EOF) // reading the source file, and writing the codes obtained in the functions to an intermediate file
  {
    for (int i = 0; i < k; i++)
      if (chh == simbols[i].ch)
      fputs(simbols[i].code,fp2);
  }
  fclose(fp2);
 
  int i = 0;
  fp2 = fopen("teemp.txt","rb");//Reopen the file with the binary code, but now for reading
  while((chh = fgetc(fp2)) != EOF) fsize2++; // Сalculate the size of the binary file (the number of characters in it)
 
  ts = fsize2%8; //find the remainder, the number of characters not divisible by 8 (tail)
 
  //form the header of the compressed file through byte fields
  fwrite("Compresing", sizeof(char), 24, fp3); 
  fwrite(&k,sizeof(int), 1, fp3); //number of unique characters
  fwrite(&ts,sizeof(int), 1, fp3); //tail size
    for (i = 0; i < k; i++)//Write the occurrence table to a compressed file
  {
    fwrite(&simbols[i].ch, sizeof(sym), 1, fp3);
    fwrite(&simbols[i].freq, sizeof(sym), 1, fp3);
  }
 
  rewind(fp2); //return the pointer in the intermediate file to the beginning of the file
 
  union code code1; 
  j = 0;
  for (int i = 0; i < fsize2-ts; i++) // read a binary file, entering sequentially every 8 elements into an array for subsequent bitwise processing in the union
  {
    mes[j] = fgetc(fp2);
    if (j == 7)
      {       
        code1.byte.b1 = mes[0]-'0';
        code1.byte.b2 = mes[1]-'0';
        code1.byte.b3 = mes[2]-'0';
        code1.byte.b4 = mes[3]-'0';
        code1.byte.b5 = mes[4]-'0';
        code1.byte.b6 = mes[5]-'0';
        code1.byte.b7 = mes[6]-'0';
        code1.byte.b8 = mes[7]-'0';
        fputc(code1.chhh,fp3);
        j = 0;
      }
    j++;    
  }

  //Writing the tail
  j = 0;
  for (int i = 0; i <= ts; i++)
  {
    mes[j] = fgetc(fp2);
    if (j == ts)
    {       
      code1.byte.b1 = mes[0]-'0';
      code1.byte.b2 = mes[1]-'0';
      code1.byte.b3 = mes[2]-'0';
      code1.byte.b4 = mes[3]-'0';
      code1.byte.b5 = mes[4]-'0';
      code1.byte.b6 = mes[5]-'0';
      code1.byte.b7 = mes[6]-'0';
      code1.byte.b8 = mes[7]-'0';
      fputc(code1.chhh,fp3);     
    }
    j++;    
  }   
  fseek(fp, 0L, SEEK_END);
  int sz = ftell(fp);
  fseek(fp2, 0L, SEEK_END);
  int sz2 = ftell(fp3);
  double kkk = sz*1.0/sz2;
  printf("\nCompaction ratio is %f", kkk);
  //printf("\nCompaction ratio is %f", count*1.0/(kk*8));
  // close all open files
  fclose(fp);
  fclose(fp2);
  fclose(fp3);
  return 0;
}