#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char * DecToSix(int x)
{
	char *e = (char *)malloc(100);
	int i = 0;
	int cnt;
	do
	{
		e[i++] = x % 2 + '0';
		x = x / 2;
	} while (x != 0);
	e[i] = '\0';
	int k = strlen(e) - 2;
	int m = k / 2;
	for (int i = 0; i <= m; i++)
	{
		char tmp = e[i];
		e[i] = e[k - i + 1];
		e[k - i + 1] = tmp;
	}
	int count=6-strlen(e);
    memmove( e + count, e, strlen( e )+1 );
    memset( e, '0', count );
    printf("%s\t",e);
	return e;
}

int main()
{
int n=1;
int i;
int in[30]={0,0,0,1,1,1,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0};
    for(i=0;i<28;i++)
        printf("%d",in[i]);
    printf("\n");
    for (i=1;i<28;i++,n+=1)
    {
    if (in[i]!=in[i-1])
    {
    DecToSix(n);
    n=0;
    }
    }
DecToSix(n-1);
puts("000000");
}

