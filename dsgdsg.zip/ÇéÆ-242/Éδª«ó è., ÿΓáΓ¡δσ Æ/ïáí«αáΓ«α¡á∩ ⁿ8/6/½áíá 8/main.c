#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int max(int a, int b) {
    return (a > b) ? a : b;
}

char *add_bin(char *str1, char *str2, int n1, int n2) {
    int i, i1, i2, k, p, nn;
    char *res_bin_str;

    nn = max(n1, n2);

    res_bin_str = (char *) malloc((nn + 2) * sizeof(char));
    for (i = 0; i < nn + 1; i++) res_bin_str[i] = '0';

    p = 0;
    i1 = n1 - 1;
    i2 = n2 - 1;

    for (i = nn - 1; i >= 0; i--) {
        k = 0;
        if (i1 >= 0) k += str1[i1] - '0';
        if (i2 >= 0) k += str2[i2] - '0';
        k += p;
        res_bin_str[i + 1] = k % 2 + '0';

        p = k / 2;
        i1--;
        i2--;
    }

    if (p > 0) {
        res_bin_str[0] = '1';
        res_bin_str[nn + 1]='\0';
    }
    else{
        for (int j = 0; j < nn; ++j) {
            res_bin_str[j]=res_bin_str[j + 1];
        }
        res_bin_str[nn]='\0';
    }

    free(str1);
    return res_bin_str;
}


int main() {
    int multiplier=2343331;
    char str[] ="100111111";
    int len = strlen(str);

    char *bin_str = (char *) malloc(len * sizeof(char));

    strcpy(bin_str, str);
    bin_str= (char*)realloc(bin_str,(len-4)*sizeof(char));
    bin_str[len-4]='\0';


    char *res_bin_str = (char *) malloc(len * sizeof(char));

    strcpy(res_bin_str, bin_str);

    for (int j = 1; j < multiplier; ++j) {
        res_bin_str = add_bin(res_bin_str, bin_str, strlen(res_bin_str), strlen(bin_str));
    }

    strcat(res_bin_str,"1111");

    printf("%s * %d = %s\n", str,multiplier,res_bin_str);

    return 0;
}