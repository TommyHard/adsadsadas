#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <math.h>

void swap(int *a, int *b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

void bubble_sort(int **arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j][1] < arr[j + 1][1]) {
                swap(&arr[j][0], &arr[j + 1][0]);
                swap(&arr[j][1], &arr[j + 1][1]);
            }
        }
    }
}

int dec_to_bin(int n) {
    int bin = 0;
    for (int k = 1; n; k *= 10, n /= 2)
        bin += (n % 2) * k;
    return bin;
}

// запись бинарной формы в строку
void bin_string(int *bin, int digit, char *buf, int n) {
    for (int i = 0; i < n; ++i) {
        if (i < n - digit)
            buf[i] = '0';
        else
            buf[i] = bin[i - n + digit] + 48;
    }
    buf[n] = '\0';
}

int digit_amount(int n) {
    int d = 0;
    while (n) {
        n /= 10;
        d++;
    }
    return d;
}

// первое вхождение символа в топ 8,
int str_chr(char *common, char c) {
    for (int i = 0; i < 8; ++i) {
        if (c == common[i])
            return 1;
    }
    return 0;
}

// запись числа в массив цифр
void num_array(int n, int *num, int size) {
    for (int i = 0; i < size; i++, n /= 10)
        num[size - i - 1] = n % 10;
}

int bin_to_dec(int bin, int n) {
    int dec = 0;
    if (n == 8) {
        for (int i = n - 1; i >= 0; i--, bin /= 10) {
            dec += (bin % 10) * pow(2, i);
        }
    }
    if (n == 3) {
        for (int i = 0; i < n; ++i, bin /= 10) {
            dec += (bin % 10) * pow(2, i);
        }
    }
    return dec;
}

char num_to_symbol(int n, char *common) {
    for (int i = 0; i < 8; i++)
        if (n == i)
            return common[i];
}

void symbols_chain(char *a) {
    int tmp;
    for (int i = 0; i < strlen(a) - 1; i++) {
        for (int j = i + 1; j < strlen(a); ++j) {
            if (a[i] == a[j]) {
                while (a[i] != a[i + 1]) {
                    tmp = (int) a[j - 1];
                    a[j - 1] = a[j];
                    a[j] = tmp;
                    j--;
                }
                i++;
            }
        }
    }
}

int symbols_array_writing(char *a, int **symbols) {
    int begin, p = 0;
    for (int i = 0; i < strlen(a); ++i) {
        if (a[i] == a[i + 1]) {
            begin = i;
            while (a[i] == a[i + 1]) i++;
            symbols[p][0] = (int) a[i];
            symbols[p++][1] = 1 + i - begin;
        } else {
            symbols[p][0] = (int) a[i];
            symbols[p++][1] = 1;
        }
    }
    return p;
}

void common_filling(char *common, int **symbols) {
    int n = 8;
    for (int i = 0; i < n; i++)
        common[i] = symbols[i][0];
}

void encryption(char *encrypted, char *tmp, char *common) {
    int c = 0;
    int tmp_bin, tmp_amount_digit;
    char buf[8], buf_common[3];
    int tmp_num[8];
    for (int i = 0; i < strlen(tmp); ++i) {
        if (str_chr(common, tmp[i]) == 0) {
            encrypted[c++] = '1';
            tmp_bin = dec_to_bin(tmp[i]);
            tmp_amount_digit = digit_amount(tmp_bin);
            num_array(tmp_bin, tmp_num, tmp_amount_digit);
            bin_string(tmp_num, tmp_amount_digit, buf, 8);
            for (int j = 0; j < 8; ++j) {
                encrypted[c + j] = buf[j];
            }
            c += 8;
        } else {
            encrypted[c++] = '0';

            int number;
            for (int q = 0; q < 8; ++q) {
                if (tmp[i] == common[q])
                    number = q;
            }
            tmp_bin = dec_to_bin(number);
            // подсчет количества цифр в бин. форме
            tmp_amount_digit = digit_amount(tmp_bin);
            num_array(tmp_bin, tmp_num, tmp_amount_digit);
            bin_string(tmp_num, tmp_amount_digit, buf_common, 3);
            for (int j = 0; j < 3; ++j) {
                encrypted[c + j] = buf_common[2 - j];
            }
            c += 3;
        }
    }
    encrypted[c] = '\0';
}

void decryption(char *encrypted, char *decrypted, int c, char *common) {
    int buf_dec;
    int size = 8, size_c = 3;
    int buf_bin;
    int q = 0;
    for (int i = 0; i < c; ++i) {
        if (encrypted[i] == '0') {
            buf_bin = 0;
            for (int j = i + 1, k = 0, p = 1; j < i + 1 + size_c; ++j, k++, p *= 10) {
                buf_bin += p * (encrypted[j] - 48);
            }
            buf_dec = bin_to_dec(buf_bin, size_c);
            i += size_c;
            decrypted[q++] = num_to_symbol(buf_dec, common);
        } else {
            buf_bin = 0;
            for (int j = i + 1, p = 1; j < i + 1 + size; ++j, p *= 10) {
                buf_bin += p * (encrypted[j] - 48);
            }
            buf_dec = bin_to_dec(buf_bin, size);
            decrypted[q++] = buf_dec;
            i += size;
        }
    }
    decrypted[q] = '\0';
}

void print_symbols(int **symbols, int amount) {
    printf("Symbols:\n_________\n");
    for (int i = 0; i < amount; ++i) {
        printf(" \"%c\" ", symbols[i][0]);
        printf("- %d ", symbols[i][1]);
        if ((i + 1) % 8 == 0)
            printf("\n");
    }
    printf("\n_________\n");
}

int main() {
    int N = 100;
    int **symbols = (int **) malloc(N * sizeof(int *));
    for (int i = 0; i < N; i++)
        symbols[i] = (int *) malloc(sizeof(int));

    char *string = (char *) malloc(sizeof(char) * 1000);
    printf("enter string:\n");
    gets(string);
    char *tmp = (char *) malloc(N * sizeof(char));
    strcpy(tmp, string);

    symbols_chain(string);

    int amount = symbols_array_writing(string, symbols);
    bubble_sort(symbols, amount);
    print_symbols(symbols, amount);
    int enc_size = 0;
    for (int i = 0; i < amount; ++i) {
        if (i < 8)
            enc_size += symbols[i][1] * (3 + 1);
        else
            enc_size += symbols[i][1] * (8 + 1);
    }

    char common[8];// массив 8 наиболее встречающихся символов
    common_filling(common, symbols);// заполнение массива

    char *encrypted = (char *) malloc(enc_size * sizeof(char));
    encryption(encrypted, tmp, common);
    printf("encrypted string:\n%s\n", encrypted);

    char *decrypted = (char *) malloc(sizeof(char) * strlen(tmp));
    decryption(encrypted, decrypted, enc_size, common);
    printf("decrypted string:\n%s\n", decrypted);
    return 0;
}


// Logic will get you from A to B. Imagination will take you anywhere. Albert Einstein