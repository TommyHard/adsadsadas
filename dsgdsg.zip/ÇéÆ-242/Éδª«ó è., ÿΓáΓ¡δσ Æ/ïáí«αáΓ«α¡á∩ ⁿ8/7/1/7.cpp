#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <time.h>
#include <malloc.h>

typedef struct list{
	struct list* next;
	int val;
}list;

/*----------------------------FOR LIST----------------------------*/
void forE(list* l, void (*pf)(void))
{
	for (; l != NULL; l = l->next)
		(*pf)(l->val);
}

void push(list* l, int n)
{
	while (l->next != NULL)
		l = l->next;
	l->next = (list*)malloc(sizeof(list));
	l = l->next;
	l->val = n;
	l->next = NULL;
}

list* create(int n)
{
	int i = 0;
	list* l = (list*)malloc(sizeof(list)), *o;
	l->next = NULL;
	l->val = rand() % 10;
	o = l;
	for (i = 1; i < n; i++)
		push(l, rand() % 10);
	
	return o;
}

int maxLVAL(list* l)//seek max elem
{
	int m = -1;
	while (l != NULL)
	{
		if (l->val > m)
			m = l->val;
		l = l->next;
	}

	return m;
}

list* maxLLIST(list* l)//seek max elem
{
	int m = -1;
	list* l1 = l;
	while (l != NULL)
	{
		if (l->val > m)
		{
			m = l->val;
			l1 = l;
		}
		l = l->next;
	}

	return l1;
}


list* minLLIST(list* l)//seek min elem
{
	int m = maxLVAL(l);
	list* l1 = l;
	while (l != NULL)
	{
		if (l->val < m)
		{
			m = l->val;
			l1 = l;
		}
		l = l->next;
	}

	return l1;
}

list* rem(list* l, list* head)
{
	list* tmp = head;
	if (l == head)
	{
		head = head->next;
	}
	else
	{
		while (tmp->next != l)
			tmp = tmp->next;
		tmp->next = l->next;
	}

	return head;
}

list* sortListCat(list* head, list*(*p1)(list*))//start list we raplace on anti-sort elem(min -> max and back)
{
	list* tmp = (list*)malloc(sizeof(list));
	tmp->next = NULL;
	tmp->val = p1(head)->val;
	head = rem(p1(head), head);

	while (head != NULL)
	{
		push(tmp, p1(head)->val);
		head = rem(p1(head), head);
	}

	return tmp;
}
/*----------------------------FOR LIST----------------------------*/
/*----------------------------FOR ARRAY----------------------------*/

void pr1(int n)//write element
{
	printf("%d ", n);
}

void createArray(int** a)
{
	for (int i = 0; a[i] != NULL; i++)
	{
		a[i] = (int*)malloc(sizeof(int));
		*(a[i]) = rand() % 10;
	}
}

void printArray(int** a)
{
	for (int i = 0; a[i] != NULL; i++)
		printf("%d ", *(a[i]));
	printf("\n");
}

int compareMaxBool(int a, int b)//compare and return max elem
{
	if (a > b)
		return 1;
	else
		return 0;
}
int compareMinBool(int a, int b)//compare and return min elem
{
	if (a < b)
		return 1;
	else
		return 0;
}

void sortBublePro(int** a, int(*pp)(int, int))
{
	int* c = NULL;

	for (int i = 0; a[i+1] != NULL; i++)
		for(int j = i+1;a[j] != NULL;j++)
			if (!pp(*(a[i]), *(a[j])))
			{
				c = a[i];
				a[i] = a[j];
				a[j] = c;
			}
}
/*----------------------------FOR ARRAY----------------------------*/


int main()
{
	srand(time(NULL));
	int n, choice, choice1;
	list* l;
	int** a;

	printf("What do you want to choose?\n1. list\n2. array\n");
	scanf("%d", &choice);
	switch (choice)
	{
	case 1://if we choice a list
		printf("How many items should be in the list?\n");
		scanf("%d", &n);

		l = create(n);

		printf("List:\n");
		forE(l,&pr1);
		printf("\n");

		printf("How will we sort it?\n1. MinToMax\n2. MaxToMin\n");
		scanf("%d",&choice1);
		switch (choice1)
		{
		case 1: 
			l = sortListCat(l, &minLLIST);//give function function of seek min elem
			printf("Sorter list:\n");
			forE(l, &pr1);
			break;
		case 2:
			l = sortListCat(l, &maxLLIST);//give function function of seek max elem
			printf("Sorter list:\n");
			forE(l, &pr1); 
			break;
		default:
			printf("Error! You write not there numbers.\n");
			break;
		}
		break;
	case 2:
		printf("How many items should be in the array?\n");
		scanf("%d", &n);
		n++;

		a = (int**)malloc(n * sizeof(int*));
		a[n - 1] = NULL;

		createArray(a);
		printf("Array:\n");
		printArray(a);

		printf("How will we sort it?\n1. MinToMax\n2. MaxToMin\n");
		scanf("%d", &choice1);

		switch (choice1)
		{
		case 1:

			sortBublePro(a, &compareMinBool);//give function function of seek min elem
			printf("Sorter array:\n");
			printArray(a);

			break;
		case 2:

			sortBublePro(a, &compareMaxBool); //give function function of seek max elem
			printf("Sorter array:\n");
			printArray(a);

			break;
		default:
			break;
		}

		break;
	default:
		printf("Error! You write not there numbers.\n");
		break;
	}
	
	return 0;
}